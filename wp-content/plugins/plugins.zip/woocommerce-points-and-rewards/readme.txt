=== WooCommerce Points and Rewards ===
Author: woothemes
Tags: woocommerce
Requires at least: 3.5
Tested up to: 3.5.1
Requires WooCommerce at least: 2.0.5
Tested WooCommerce up to: 2.0.12

Reward customers for purchases and other actions with points which can be redeemed for discounts

See http://docs.woothemes.com/document/woocommerce-points-and-rewards/ for full documentation.

== Installation ==

1. Upload the entire 'woocommerce-points-and-rewards' folder to the '/wp-content/plugins/' directory
2. Activate the plugin through the 'Plugins' menu in WordPress

