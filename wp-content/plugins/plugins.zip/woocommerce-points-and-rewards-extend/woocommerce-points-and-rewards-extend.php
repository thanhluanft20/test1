<?php
/*
Plugin Name: Woocommerce Points And Rewards Extend
Plugin URI: http://izweb.biz
Description: Create a Refer-a-Friend Reward System for WooCommerce 
Version: 1.1.1
Author: Sy Le
Author URI: http://izweb.biz
*/

// add a setting to allow store owner to set points for friend referral
add_filter( 'wc_points_rewards_action_settings', 'wdm_points_rewards_friend_referral_settings' );
function wdm_points_rewards_friend_referral_settings( $settings ) {
	$settings[] = array(
		'title'    => __( 'Points earned for Referring a Friend' ),
		'desc_tip' => __( 'Enter the amount of points earned when a customer refers a friend.' ),
		'id'       => 'wdm_points_rewards_friend_referral',
	);
return $settings;
}

// on submitting the form, we need to add the following function.
add_action('wdm_after_refer_friend_submit', 'wdm_points_rewards_friend_referral_action' );
function wdm_points_rewards_friend_referral_action( $referred_friend ) {
	if ( is_user_logged_in() ){
		// get the points associated with friend referral action
		$points = get_option( 'wdm_points_rewards_friend_referral' );
		if ( ! empty( $points ) ) {
			WC_Points_Rewards_Manager::increase_points( get_current_user_id(), $points, 'refer-a-friend-success', $referred_friend );
		}
	}
}

add_filter('wc_points_rewards_event_description', 'add_points_rewards_newsletter_action_event_description', 10, 3 );
function add_points_rewards_newsletter_action_event_description( $event_description, $event_type, $event ) {
	$points_label = get_option( 'wc_points_rewards_points_label' );
	switch ( $event_type ) {
		case 'refer-a-friend-success': $event_description = sprintf( __( '%s earned for referring a friend.' ), $points_label ); break;
	}
	return $event_description;
}
add_action("woocommerce_before_my_account",'add_link_into_myaccount');
function add_link_into_myaccount(){
    $currentuser = wp_get_current_user();
    _e("Your link refer a friend / family is ",'woocommerce');
    ?>
    <input type="text" readonly name="referurl" value="<?php echo home_url("/?refer=").md5($currentuser->ID); ?>" class="regular-text" />
    <?php
}