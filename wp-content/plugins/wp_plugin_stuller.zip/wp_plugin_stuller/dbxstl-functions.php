<?php

// The API is WAAAAAAAAYYYY  too slow to do it this way
function dbxstlStullerLoadSloooooow()
{
    global $wpdb;
    $tableProducts = $wpdb->prefix . "dbxstl_products";

    // Give me everythin I can sell !
    $data = array(
        'Include' => array('All'),
        'Filter' => array('Orderable','OnPriceList','Finished'),
    );
    print "Calling Stuller API<br/>\n";

    $nbProducts = 0;
    $TotalNumberOfProducts = 0;
    do {
        $resultObj = json_decode(dbxstlStullerCallProduct(json_encode($data)));
        if($resultObj === null){
            print_r($result);
            print "==== ERROR ====<br/>\n";
            $pageSize = 0;
            $data = array();
        }else{
            foreach($resultObj->Products as $x => $prod){
                $nbProducts++;
                $dataJson = json_encode($prod);

                $inserts = ""
                    . "Sku='". mysql_real_escape_string($prod->SKU). "'"
                    . ",Description='". mysql_real_escape_string($prod->Description)."'"
                    . ",ShortDescription='". mysql_real_escape_string($prod->ShortDescription)."'"
                    . ",MerchandisingCategory1='". mysql_real_escape_string($prod->MerchandisingCategory1)."'"
                    . ",MerchandisingCategory2='". mysql_real_escape_string($prod->MerchandisingCategory2)."'"
                    . ",MerchandisingCategory3='". mysql_real_escape_string($prod->MerchandisingCategory3)."'"
                    . ",MerchandisingCategory4='". mysql_real_escape_string($prod->MerchandisingCategory4)."'"
                    . ",MerchandisingCategory5='". mysql_real_escape_string($prod->MerchandisingCategory5)."'"
                    . ",ProductType='". mysql_real_escape_string($prod->ProductType)."'"
                    . ",Collection='". mysql_real_escape_string($prod->Collection)."'"
                    . ",OnHand='". mysql_real_escape_string($prod->OnHand)."'"
                    . ",Status='". mysql_real_escape_string($prod->Status)."'"
                    . ",Price='". mysql_real_escape_string($prod->Price)."'"
                    . ",UnitOfSale='". mysql_real_escape_string($prod->UnitOfSale)."'"
                    . ",data_json='". mysql_real_escape_string($dataJson)."'";


                $query = "INSERT INTO $tableProducts SET date_added=now(),$inserts"
                    . " ON DUPLICATE KEY UPDATE $inserts";
                //print "$q=[$query]\n";
                $wpdb->query($query);
            }
            $pageSize = (int)$resultObj->PageSize;
            $TotalNumberOfProducts = (int)$resultObj->TotalNumberOfProducts;
            $data = array('NextPage' => $resultObj->NextPage);
        }
        print "Product $nbProducts of $TotalNumberOfProducts<br/>\n";
        flush();
        set_time_limit(60); // Give Stuller 30 seconds ton respond to one call.
    } while ($pageSize == 200);
}

function dbxstlStullerLoad()
{
    global $wpdb;

    $tableRaw = $wpdb->prefix . "dbxstl_raw";
    $tableProducts = $wpdb->prefix . "dbxstl_products";

    $listDefaultFields = array(
        'Sku',
        'Description','ShortDescription','GroupDescription',
        'MerchandisingCategory1','MerchandisingCategory2',
        'MerchandisingCategory3','MerchandisingCategory4',
        'MerchandisingCategory5',
        'ProductType','Collection','OnHand','Status','Price','UnitOfSale',
        'Weight','WeightUnitOfMeasure','GramWeight',
        'RingSizable','RingSize','RingSizeType',
        'LeadTime',
        'DescriptiveElementGroup',
        'DescriptiveElementName1','DescriptiveElementValue1',
        'DescriptiveElementName2','DescriptiveElementValue2',
        'DescriptiveElementName3','DescriptiveElementValue3',
        'DescriptiveElementName4','DescriptiveElementValue4',
        'DescriptiveElementName5','DescriptiveElementValue5',
        'DescriptiveElementName6','DescriptiveElementValue6',
        'DescriptiveElementName7','DescriptiveElementValue7',
        'DescriptiveElementName8','DescriptiveElementValue8',
        'DescriptiveElementName9','DescriptiveElementValue9',
        'DescriptiveElementName10','DescriptiveElementValue10',
        'DescriptiveElementName11','DescriptiveElementValue11',
        'DescriptiveElementName12','DescriptiveElementValue12',
        'DescriptiveElementName13','DescriptiveElementValue13',
        'DescriptiveElementName14','DescriptiveElementValue14',
        'DescriptiveElementName15','DescriptiveElementValue15',
        'ReadyToWear','Image1','Image2','Image3',
        'Video','VideoType',
        'GroupImage1','GroupImage2','GroupImage3',
        'GroupVideo','GroupVideoType','CreationDate'


    );


//    $query="SELECT ProductType,count(*) as total FROM  wp_dbxstl_raw GROUP BY 1";

    $strFields = join($listDefaultFields,',');

    $strUpdates = '';
    foreach($listDefaultFields as $field){
        $strUpdates .= "$field=values($field),";
    }

    $query = "insert into $tableProducts ($strFields,in_raw,date_added) "
        . "(select $strFields,1,date(now()) as date_added from $tableRaw)"
        . " ON DUPLICATE KEY UPDATE $strUpdates" . "in_raw=(1)";

    //print $query;
    //exit;

    $rows = $wpdb->get_results($query);


}
function dbxstlStullerCallProduct($data)
{
    $query = "https://www.stuller.com/api/v1/products";
    return dbxstlStullerCall($query,$data);
}

function dbxstlStullerCallOrder($data)
{
    /*
     * 
     *   N O T   R E A D Y
     * 
     * 
     */
    $query = "https://www.stuller.com/api/v1/orders";
    return dbxstlStullerCall($query,$data);
}

function dbxstlStullerCall($query,$data)
{
    $header = array();
    $curl = curl_init();
    curl_setopt($curl, CURLOPT_SSL_VERIFYHOST,0);
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER,0);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER,1);
    $header[0] = "Authorization: Basic ".
        base64_encode(get_option('dbxstl_user') . ":" . get_option('dbxstl_pass'));
    $header[1] = "Content-Type: application/json; charset=utf-8";
    curl_setopt($curl,CURLOPT_HTTPHEADER,$header);
    curl_setopt($curl, CURLOPT_URL, $query);
    curl_setopt($curl, CURLOPT_POST, 1);
    curl_setopt($curl, CURLOPT_POSTFIELDS,"$data");
    $result = curl_exec($curl);
    if ($result == false) {
        $msg = "curl_error [" . curl_error($curl) . "]\n";
#            $msg .= "url [$query]\n";
        error_log($msg);
        curl_close($curl);
        exit;
    }
    curl_close($curl);
    return $result;
}
/*
 * Import Product With Product ID
 */
function import_product($product_id = 0)
{
    global $wpdb;

    $product_id = (int)$product_id;
    $product_id_original = $product_id;
    $tableProducts = $wpdb->prefix . "dbxstl_products";

    $query="SELECT * FROM  $tableProducts where product_id=$product_id limit 1";
    $rows = $wpdb->get_results($query);

    //get data from API
    if (isset($rows[0])) {
        $row = $rows[0];
        $data = array(
            'Include' => array('All'),
            'SKU' => array($row->Sku),
            'Filter' => array('None'),
        );

        //
        $result = json_decode(dbxstlStullerCallProduct(json_encode($data)));
    }

    if(empty($result->Products[0])){
        return false;
    }else{
        $type = 'import';
        $_product = $result->Products[0];

        $product_title = !empty($_product->Description)?$_product->Description:$_product->ShortDescription;
        $product_content = $_product->ShortDescription;

        //test SKU if exist
        $product_id = $wpdb->get_var( $wpdb->prepare( "SELECT post_id FROM $wpdb->postmeta WHERE meta_key='_InternalSku' AND meta_value='%s' LIMIT 1", $_product->SKU ) );

        //prepare data array
        $product_data = array(
            'post_title' 	=> $product_title,
            'post_content' 	=> $product_content,
            'post_status' 	=> 'publish',
            'post_author' 	=> get_current_user_id(),
            'post_type' 	=> 'product'
        );

        if (!empty($product_id)) $product_data['ID'] = $product_id;
        $imported = get_post_meta($product_id, '_imported', true) ? get_post_meta($product_id, '_imported', true) : '';
        /*if($imported == 'yes'){
            $query="UPDATE $tableProducts set row_status='selected' where product_id=$product_id_original limit 1";
            $wpdb->query($query);
            return array($product_id,'imported');
        }*/

        $product_id = wp_insert_post($product_data);

        //insert to custom meta
        update_post_meta($product_id, '_regular_price', round($_product->Price->Value,2));
        update_post_meta($product_id, '_price', round($_product->Price->Value,2));
        update_post_meta($product_id, '_weight', $_product->Weight);
        update_post_meta($product_id, '_visibility', 'visible');
        update_post_meta($product_id, '_stock_status', 'instock');
        update_post_meta($product_id, '_imported', 'yes');

        // SKU dislayed is not the Supplier's SKU
        update_post_meta($product_id, '_InternalSku', $_product->SKU);
        update_post_meta($product_id, '_sku', 'STL' . sprintf("%07d",$product_id));

        foreach($_product->WebCategories as $cat){
            wp_set_post_terms( $product_id, $cat->Name, 'product_cat' );
        }
        
        if (!empty($_product->Images)) {
            $filenameUrl =  $_product->Images[0]->FullUrl . '&filetype=.jpg';
            $filename = strtolower("$product_title");
            $filename = preg_replace('/[^\da-z]/i', '_', $filename)  . '.jpg';
            
            $uploaddir = wp_upload_dir();
            $uploadFile = $uploaddir['path'] . '/' . $filename;
            $filenamSub = $uploaddir['subdir'] . '/' . $filename;

            $savefile = fopen($uploadFile, 'w');
            $contents = file_get_contents($filenameUrl);
            fwrite($savefile, $contents);
            $contents = '';
            fclose($savefile);

            update_post_meta($product_id, '_product_feature_image', $filenamSub);
            $wp_filetype = wp_check_filetype(basename($filename), null);

            $attachment = array(
                'post_mime_type' => $wp_filetype['type'],
                'post_title' => $product_title,
                'post_content' => '',
                'post_status' => 'inherit'
            );
            $attach_id = wp_insert_attachment($attachment, $uploadFile);
            $attach_data = wp_generate_attachment_metadata($attach_id, $uploadFile);
            wp_update_attachment_metadata($attach_id, $attach_data);
            update_post_meta( $product_id, '_thumbnail_id', $attach_id );
        }
        /*
         * UPLOAD PRODUCT GALLERY
         */
        if (!empty($_product->GroupImages)) {
            $groupIMGCount = count($_product->GroupImages);
            $i=1;
            foreach($_product->GroupImages as $rows){
                $attach_id = dbxstl_upload_product_gallery($rows->FullUrl);
                if( $i == $groupIMGCount )
                    update_post_meta($product_id, '_product_image_gallery', $attach_id); // IF Not Last Element
                else
                    update_post_meta($product_id, '_product_image_gallery', $attach_id.","); // IF Last Element
                $i++;
            }
        }
        
        update_post_meta($product_id, 'ProductSource', 'dbxstl');
        update_post_meta($product_id, 'OnHand', $_product->OnHand);
        update_post_meta($product_id, 'Status', $_product->Status);
        update_post_meta($product_id, 'Orderable', $_product->Orderable);
        update_post_meta($product_id, 'IsOnPriceList', $_product->IsOnPriceList);
        update_post_meta($product_id, 'UnitOfSale', $_product->UnitOfSale);
        update_post_meta($product_id, 'GramWeight', $_product->GramWeight);
        update_post_meta($product_id, 'LeadTime', $_product->LeadTime);
        update_post_meta($product_id, 'StoneMapImagee', $_product->StoneMapImage);
        update_post_meta($product_id, 'ReadyToWear', $_product->ReadyToWear);
        update_post_meta($product_id, 'AGTA', $_product->AGTA);
        update_post_meta($product_id, 'ProductType', $_product->ProductType);
        update_post_meta($product_id, 'DescriptiveElementGroup', serialize( $_product->DescriptiveElementGroup ) );
        update_post_meta($product_id, 'SetWith', serialize( $_product->SetWith ));
        update_post_meta($product_id, 'MadeWith', serialize( $_product->MadeWith ));
        //update_post_meta($product_id, 'GroupImages', serialize( $_product->GroupImages ));

        wp_set_object_terms( $product_id, strtolower($_product->ProductType), 'product_cat' );
        $query="UPDATE $tableProducts set row_status='selected' where product_id=$product_id_original limit 1";
        $wpdb->query($query);
    }
    return array($product_id,$type);
}


function dbxstlStullerGetBasic($data)
{
    /*
     * 
     *   Get the Static Product file so we can fill the _raw file
     * 
     * 
     */
    $query = "https://www.stuller.com/api/v1/Exports/StaticExport?Type=Basic";
    $data = array();

    $zipFile = fopen('data.txt', 'w');
    fwrite($zipFile,dbxstlStullerCall($query,$data));
    fclose($zipFile);

    // Unzip 
    // Load .csv into _raw file
}
function dbxstl_upload_product_gallery($url){
    $filenameUrl =  $url . '&filetype=.jpg';
    $filename = microtime().'.jpg';

    $uploaddir = wp_upload_dir();
    $uploadFile = $uploaddir['path'] . '/' . $filename;
    $filenamSub = $uploaddir['subdir'] . '/' . $filename;

    $savefile = fopen($uploadFile, 'w');
    $contents = file_get_contents($filenameUrl);
    fwrite($savefile, $contents);
    $contents = '';
    fclose($savefile);

    $wp_filetype = wp_check_filetype(basename($filename), null);

    $attachment = array(
        'post_mime_type' => $wp_filetype['type'],
        'post_title' => $filename,
        'post_content' => '',
        'post_status' => 'inherit'
    );
    $attach_id = wp_insert_attachment($attachment, $uploadFile);
    $attach_data = wp_generate_attachment_metadata($attach_id, $uploadFile);
    wp_update_attachment_metadata($attach_id, $attach_data);
    return $attach_id;
}