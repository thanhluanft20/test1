<?php
if(!defined('dbxstl_preload')) {
    echo 'error';
    exit;
}

if(!class_exists('WP_List_Table')){
    require_once( ABSPATH . 'wp-admin/includes/class-wp-list-table.php' );
}

class dbxstl_List_Table extends WP_List_Table {
    function __construct(){
        global $status, $page;

        //Set parent defaults
        parent::__construct( array(
            'singular'  => 'prid',     //singular name of the listed records
            'plural'    => 'products',    //plural name of the listed records
            'ajax'      => false        //does this table support ajax?
        ) );

    }
    function column_default($item, $column_name){
        switch($column_name){
            case 'image':
            case 'product_code':
            case 'sku':
            case 'product_type':
            case 'description':
            case 'status':
            case 'date_added':
                return $item[$column_name];
            default:
                return print_r($item,true); //Show the whole array for troubleshooting purposes
        }
    }

    function column_image($item){
        //Build row actions
        $actions = array(
            'edit'      => sprintf('<a href="?page=%s&act=%s&prid=%s">Edit</a>',$_REQUEST['page'],'edit',$item['ID']),
            'delete'    => sprintf('<a href="?page=%s&act=%s&group=%s&type=%s&action=%s&prid=%s">Delete</a>',$_REQUEST['page'],$_REQUEST['act'],$_REQUEST['group'],$_REQUEST['type'],'delete',$item['ID']),
        );

        return sprintf('%1$s %2$s',
            /*$1%s*/ $item['image'],
            /*$2%s*/ $this->row_actions($actions)
        );
    }

    /** ************************************************************************
     * @see WP_List_Table::::single_row_columns()
     * @param array $item A singular item (one full row's worth of data)
     * @return string Text to be placed inside the column <td> (movie title only)
     **************************************************************************/
    function column_cb( $item )
    {
        if(isset($item['status']) && $item['status'] != 'selected' ) {
            return sprintf(
                '<input type="checkbox" name="%1$s[]" value="%2$s" />',
                /*$1%s*/ $this->_args['singular'],  //Let's simply repurpose the table's singular label ("movie")
                /*$2%s*/ $item['ID']                //The value of the checkbox should be the record's id
            );
        }else{
            return '&nbsp;';
        }
    }

    function get_columns(){
        $columns = array(
            'cb'            => '<input type="checkbox" />', //Render a checkbox instead of text
            'image'         => 'Image',
            'product_code'  => 'Product Code',
            'sku'           => 'SKU',
            'product_type'  => 'Product Type',
            'description'   => 'Description',
            'status'        => 'Status',
            'date_added'    => 'Date Added',
        );
        return $columns;
    }
    /** ************************************************************************
     * @return array An associative array containing all the columns that should be sortable: 'slugs'=>array('data_values',bool)
     **************************************************************************/
    function get_sortable_columns() {
        $sortable_columns = array(
            'sku'=> array('sku',false),   //true means it's already sorted
            'product_type'=> array('product_type',false),
            'description'=> array('description',false),
            'status'=> array('status',false),
            'date_added'  => array('date_added',false)
        );
        return $sortable_columns;
    }

    function get_bulk_actions() {
        $actions = array(
            'delete'    => 'Delete',
            'import'    => 'Import'
        );
        return $actions;
    }

    function process_bulk_action() {
        //Detect when a bulk action is being triggered...
        if( 'delete'===$this->current_action() ) {

            //wp_die('Items deleted (or they would be if we had items to delete)!');
            if( is_array( $_REQUEST['prid'] ) ){
                foreach( $_REQUEST['prid'] as $product )
                    $this->delete_product( $product );
            }else $this->delete_product( $_REQUEST['prid'] );
            ?>
            <div class="updated">
                <p><?php _e( 'Deleted!', 'my-text-domain' ); ?></p>
            </div>
        <?php
        }elseif( 'import'===$this->current_action() ){
            $error = new WP_Error();
            if( is_array( $_REQUEST['prid'] ) ){
                foreach( $_REQUEST['prid'] as $product ){
                    list($product_id,$type) = import_product( $product );
                    $productData = get_post($product_id);
                    if($product_id && $type == 'import'){
                        $error->add('import_prid_'.$product_id,sprintf('<div class="updated"><p>Import Product <strong>%s</strong> Success!</p></div>',$productData->post_title));
                    }elseif($product_id && $type == 'imported'){
                        $error->add('import_prid_'.$product_id,sprintf('<div class="error"><p>This <strong>%s</strong>Error: Already imported!</p></div>',$productData->post_title));
                    }
                }

            }else {
                list($product_id,$type) = import_product( $_REQUEST['prid'] );
                $productData = get_post($product_id);
                if($product_id && $type == 'import'){
                    $error->add('import_prid_'.$product_id,sprintf('<div class="updated"><p>Import Product <strong>%s</strong> Success!</p></div>',$productData->post_title));
                }elseif($product_id && $type == 'imported'){
                    $error->add('import_prid_'.$product_id,sprintf('<div class="error"><p>This <strong>%s</strong>Error: Already imported!!</p></div>',$productData->post_title));
                }
            }
            if($error->get_error_messages()){
                foreach ($error->get_error_messages() as $rows):
                    echo $rows;
                endforeach;
            }
        }
    }
    function delete_product($id = 0){
        global $wpdb;
        $tableProducts = $wpdb->prefix . "dbxstl_products";
        $where = array(
            'product_id' => $id
        );
        $wpdb->delete( $tableProducts, $where );
    }

    function prepare_items() {
        global $wpdb;
        $per_page = 50;

        $columns = $this->get_columns();
        $hidden = array('ID');
        $sortable = $this->get_sortable_columns();

        $this->_column_headers = array($columns, $hidden, $sortable);

        $this->process_bulk_action();

        $tableProducts = $wpdb->prefix . "dbxstl_products";
        $validGroups = array(
            "avail" => 1,
            "new" => 1,
            "selected" => 1,
            "deleted" => 1,
            "total" => 1,
        );
        $currentGroup = '';
        $currentType = '';
        if(isset($_GET['type'])){
            $currentType = mysql_real_escape_string($_GET['type']);
        }
        if(isset($_GET['group'])){
            $currentGroup = $_GET['group'];
        }
        if(!isset($validGroups[$currentGroup])){
            $currentGroup = 'avail';
        }
        $query="from $tableProducts ";

        $where = 'where 1=1 ';
        if($currentGroup != 'total' && $currentGroup != 'new'){
            $query .= " $where and row_status='$currentGroup'";
            $where = '';
        }elseif($currentGroup == 'new'){
            $query .= " $where and date_added > DATE_SUB(NOW(), INTERVAL 1 MONTH)";
            $where = '';
        }
        if($currentType){
            $query .= " $where and ProductType='$currentType'";
            $where = '';
        }

        $orderby = (!empty($_REQUEST['orderby'])) ? $_REQUEST['orderby'] : 'Image1'; //If no sort, default to title
        $order = (!empty($_REQUEST['order'])) ? $_REQUEST['order'] : 'asc'; //If no order, default to asc

        $limitPerPage = $per_page;
        $current_page = $this->get_pagenum();
        $page = abs( (int) $current_page ) ? abs( (int) $current_page ) : 1;
        $limitStart = (($page - 1) * $per_page);

        $data = array();
        $dataquery = $wpdb->get_results('select SQL_CALC_FOUND_ROWS * ' . $query . " ORDER BY $orderby $order limit $limitStart,$per_page " );
        foreach( $dataquery as $row ){
            $data[] = array(
                'ID'            => $row->product_id,
                'image'         => ($row->Image1 != '' ? '<img width=50 height=50 src="'.$row->Image1.'">' : '<img width=50 height=50 src="'.plugins_url('images/no_image.jpg' , dirname(__FILE__) ).'">'),
                'product_code'  => $row->product_code,
                'sku'           => '<a href="?page=dbxstl-menu-products&act=edit&prid='. $row->product_id .'">' . $row->Sku . '</a>',
                'product_type'  => $row->ProductType,
                'description'   => $row->Description,
                'status'        => $row->row_status,
                'date_added'    => $row->date_added,
            );
        }

        /*function usort_reorder($a,$b){
            $orderby = (!empty($_REQUEST['orderby'])) ? $_REQUEST['orderby'] : 'image'; //If no sort, default to title
            $order = (!empty($_REQUEST['order'])) ? $_REQUEST['order'] : 'asc'; //If no order, default to asc
            $result = strcmp($a[$orderby], $b[$orderby]); //Determine sort order
            return ($order==='asc') ? $result : -$result; //Send final sort direction to usort
        }
        usort($data, 'usort_reorder');*/


        /***********************************************************************
         * ---------------------------------------------------------------------
         * vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv
         *
         * In a real-world situation, this is where you would place your query.
         *
         * For information on making queries in WordPress, see this Codex entry:
         * http://codex.wordpress.org/Class_Reference/wpdb
         *
         * ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
         * ---------------------------------------------------------------------
         **********************************************************************/


        $dataNbRows = $wpdb->get_results('select FOUND_ROWS() as nb' );
        $total_items = $dataNbRows[0]->nb;
        //$data = array_slice($data,(($current_page-1)*$per_page),$per_page);

        $this->items = $data;

        $this->set_pagination_args( array(
            'total_items' => $total_items,                  //WE have to calculate the total number of items
            'per_page'    => $per_page,                     //WE have to determine how many items to show on a page
            'total_pages' => ceil($total_items/$per_page)   //WE have to calculate the total number of pages
        ) );
    }
}

/*function dbxstl_render_list_page(){*/

$productListTable = new dbxstl_List_Table();
//Fetch, prepare, sort, and filter our data...
$productListTable->prepare_items();

?>
    <div class="wrap">
        <!-- Forms are NOT created automatically, so you need to wrap the table in one to use features like bulk actions -->
        <form id="products-filter" method="post" action="">
            <!-- For plugins, we also need to ensure that the form posts back to our current page -->
            <input type="hidden" name="page" value="<?php echo $_REQUEST['page'] ?>" />
            <!-- Now we can render the completed list table -->
            <?php $productListTable->display() ?>
        </form>

    </div>
<?php
/*}*/