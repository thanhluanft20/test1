<?php
if(!defined('dbxstl_preload')) {
    echo 'error';
    exit;
}

if(!class_exists('WP_List_Table')){
    require_once( ABSPATH . 'wp-admin/includes/class-wp-list-table.php' );
}

class List_Data_Order_Xstl extends WP_List_Table {
    function __construct(){
        global $status, $page;

        //Set parent defaults
        parent::__construct( array(
            'singular'  => 'orderid',     //singular name of the listed records
            'plural'    => 'products',    //plural name of the listed records
            'ajax'      => false        //does this table support ajax?
        ) );

    }
    function column_default($item, $column_name){
        switch($column_name){
            case 'order_id':
            case 'status':
                return $item[$column_name];
            default:
                return print_r($item,true); //Show the whole array for troubleshooting purposes
        }
    }

    function column_product_id($item){
        //Build row actions
        $actions = array(
            //'edit'      => sprintf('<a href="post.php?post=%s&action=edit">Edit</a>',$item['product_id']),
        );
        $data = get_post($item['product_id']);
        return sprintf('<a href="post.php?post=%1$s&action=edit"><strong>%2$s</strong></a>',
            /*$1%s*/ $item['product_id'],
            /*$2%s*/ $data->post_title,
            /*$3%s*/ $this->row_actions($actions)
        );
    }
    function column_order_id($item){
        //Build row actions
        $actions = array(
            'edit'    => sprintf('<a href="post.php?post=%s&action=edit">Edit</a>',$item['order_id']),
            'delete'    => sprintf('<a class="delete" href="?page=%s&action=%s&orderid=%s">Delete</a>',$_REQUEST['page'],'delete',$item['ID'])
        );
        //$data = get_post($item['product_id']);
        return sprintf('%1$s %2$s',
            /*$1%s*/ sprintf('<a href="post.php?post=%s&action=edit"><strong>#%s</strong></a>',$item['order_id'],$item['order_id']),
            /*$2%s*/ $this->row_actions($actions)
        );
    }

    /** ************************************************************************
     * @see WP_List_Table::::single_row_columns()
     * @param array $item A singular item (one full row's worth of data)
     * @return string Text to be placed inside the column <td> (movie title only)
     **************************************************************************/
    function column_cb( $item ){
        return sprintf(
            '<input type="checkbox" name="%1$s[]" value="%2$s" />',
            /*$1%s*/ $this->_args['singular'],  //Let's simply repurpose the table's singular label ("movie")
            /*$2%s*/ $item['ID']                //The value of the checkbox should be the record's id
        );
    }

    function get_columns(){
        $columns = array(
            'cb'                    => '<input type="checkbox" />', //Render a checkbox instead of text
            'order_id'              => 'Order ID',
            'status'                => 'Order Status',
        );
        return $columns;
    }
    /** ************************************************************************
     * @return array An associative array containing all the columns that should be sortable: 'slugs'=>array('data_values',bool)
     **************************************************************************/
    function get_sortable_columns() {
        $sortable_columns = array(
            'order_id'=> array('order_id',false),   //true means it's already sorted
        );
        return $sortable_columns;
    }

    function get_bulk_actions() {
        $actions = array(
            'delete'    => 'Delete',
            'updatestatus' => 'Update Status'
        );
        return $actions;
    }

    function process_bulk_action() {
        //Detect when a bulk action is being triggered...
        if( 'delete'===$this->current_action() ) {

            //wp_die('Items deleted (or they would be if we had items to delete)!');
            if( is_array( $_REQUEST['orderid'] ) ){
                foreach( $_REQUEST['orderid'] as $orderID )
                    $this->delete_order( $orderID );
            }else $this->delete_order( $_REQUEST['orderid'] );
            ?>
            <div class="updated">
                <p><?php _e( 'Deleted!', 'my-text-domain' ); ?></p>
            </div>
        <?php
        }elseif( 'updatestatus'===$this->current_action() ){
            if( is_array( $_REQUEST['orderid'] ) ){
                foreach( $_REQUEST['orderid'] as $orderID )
                    $this->update_order_status( $orderID );
            }else $this->update_order_status( $_REQUEST['orderid'] );
            ?>
            <div class="updated">
                <p><?php _e( 'Update Order Success!', 'my-text-domain' ); ?></p>
            </div>
        <?php
        }
        //echo '<meta http-equiv="refresh" content="0;'.admin_url("/admin.php?page=".$_REQUEST['page']).'">';
    }
    /*
     * Delete Product
     */
    function delete_order($id = 0){
        global $wpdb;
        $tableOrders = $wpdb->prefix . "dbxstl_orders";
        $tableOrdersDetail = $wpdb->prefix . "dbxstl_orders_detail";
        $order_id = $wpdb->get_var("SELECT `order_id` FROM {$tableOrders} WHERE id = '{$id}'");
        $where = array(
            'id' => $id
        );
        $wpdb->delete( $tableOrders, $where );
        $wpdb->delete( $tableOrdersDetail, array('order_id' => $order_id) );
    }

    /*
     * Update Order Status
     */
    function update_order_status($id = 0){
        global $wpdb;
        $tableOrders = $wpdb->prefix . "dbxstl_orders";
        $order_id = $wpdb->get_var("SELECT `order_id` FROM {$tableOrders} WHERE `id` = '{$id}'");
        $term_list = wp_get_object_terms($order_id, 'shop_order_status');
        $flag = false;
        foreach($term_list as $row){
            $wpdb->update($tableOrders,array('order_status' => $row->slug),array('order_id' => $order_id));
            $flag = true;
            do_action('dbxstl_updated_order_status',$order_id);
        }
        return $flag;
    }

    function prepare_items() {
        global $wpdb;
        $per_page = 50;

        $columns = $this->get_columns();
        $hidden = array('ID');
        $sortable = $this->get_sortable_columns();

        $this->_column_headers = array($columns, $hidden, $sortable);

        $this->process_bulk_action();

        $orderby = (!empty($_REQUEST['orderby'])) ? $_REQUEST['orderby'] : 'id'; //If no sort, default to title
        $order = (!empty($_REQUEST['order'])) ? $_REQUEST['order'] : 'asc'; //If no order, default to asc

        $data = array();
        $tableOrders = $wpdb->prefix . "dbxstl_orders";
        $dataquery = $wpdb->get_results("SELECT * FROM `{$tableOrders}`" );
        foreach( $dataquery as $row ){
            $data[] = array(
                'ID'                    => $row->id,
                'order_id'              => $row->order_id,
                'status'                => (!empty($row->order_status)) ? $row->order_status : 'Waiting',
            );
        }

        /*function usort_reorder($a,$b){
            $orderby = (!empty($_REQUEST['orderby'])) ? $_REQUEST['orderby'] : 'image'; //If no sort, default to title
            $order = (!empty($_REQUEST['order'])) ? $_REQUEST['order'] : 'asc'; //If no order, default to asc
            $result = strcmp($a[$orderby], $b[$orderby]); //Determine sort order
            return ($order==='asc') ? $result : -$result; //Send final sort direction to usort
        }
        usort($data, 'usort_reorder');*/


        /***********************************************************************
         * ---------------------------------------------------------------------
         * vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv
         *
         * In a real-world situation, this is where you would place your query.
         *
         * For information on making queries in WordPress, see this Codex entry:
         * http://codex.wordpress.org/Class_Reference/wpdb
         *
         * ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
         * ---------------------------------------------------------------------
         **********************************************************************/

        $current_page = $this->get_pagenum();

        $total_items = count($data);

        $data = array_slice($data,(($current_page-1)*$per_page),$per_page);

        $this->items = $data;

        $this->set_pagination_args( array(
            'total_items' => $total_items,                  //WE have to calculate the total number of items
            'per_page'    => $per_page,                     //WE have to determine how many items to show on a page
            'total_pages' => ceil($total_items/$per_page)   //WE have to calculate the total number of pages
        ) );
    }
}

/*function dbxstl_render_list_page(){*/

$productListTable = new List_Data_Order_Xstl();
//Fetch, prepare, sort, and filter our data...
$productListTable->prepare_items();

?>
<div class="wrap">
    <script type="text/javascript">
        jQuery(document).ready(function ($){
            $('#doaction').click(function (){
                var actionOD = $('select[name="action"]').val();
                if(actionOD=='delete' && confirm("Do you want delete this order id?")){
                    return true;
                }else{
                    return false;
                }
            });
            $(".row-actions a.delete").click(function (){
                if(confirm("Do you want delete this order id?")){
                    return true;
                }else{
                    return false;
                }
            });
        });
    </script>
    <!-- Forms are NOT created automatically, so you need to wrap the table in one to use features like bulk actions -->
    <form id="products-filter" method="post" action="">
        <!-- For plugins, we also need to ensure that the form posts back to our current page -->
        <input type="hidden" name="page" value="<?php echo $_REQUEST['page'] ?>" />
        <!-- Now we can render the completed list table -->
        <?php $productListTable->display() ?>
    </form>
</div>