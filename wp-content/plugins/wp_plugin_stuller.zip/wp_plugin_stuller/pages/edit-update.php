<?php
if(!defined('dbxstl_preload')) {
    echo 'error';
    exit;
}

require_once(dirname(__FILE__) . '../dbxstl-functions.php');


loadStuller();