<?php
if(!defined('dbxstl_preload')) {
    echo 'error';
    exit;
}

global $wpdb;


$product_id = 0;
if(isset($_GET['prid'])){
    $product_id = (int)$_GET['prid'];
}

$query="SELECT * FROM  wp_dbxstl_products where product_id=$product_id limit 1";
$rows = $wpdb->get_results($query);

//get data from API
if (isset($rows[0])) {
    $row = $rows[0];
    $data = array(
        'Include' => array('All'),
        'SKU' => array($row->Sku),
        'Filter' => array('None'),
    );

    //
    $result = json_decode(dbxstlStullerCallProduct(json_encode($data)));
}

if(empty($result->Products[0])){
    print __("Product Not Found");
}else{
    $_product = $result->Products[0];
    if (isset($_POST['save'])) {
        $error = new WP_Error();

        /*$product_title = !empty($_product->Description)?$_product->Description:$_product->ShortDescription;
        $product_content = $_product->ShortDescription;

        //test SKU if exist
        $product_id = $wpdb->get_var( $wpdb->prepare( "SELECT post_id FROM $wpdb->postmeta WHERE meta_key='_sku' AND meta_value='%s' LIMIT 1", $_product->SKU ) );

        //prepare data array
        $product_data = array(
            'post_title' 	=> $product_title,
            'post_content' 	=> $product_content,
            'post_status' 	=> 'publish',
            'post_author' 	=> get_current_user_id(),
            'post_type' 	=> 'product'
        );

        if (!empty($product_id)) $product_data['ID'] = $product_id;

        $product_id = wp_insert_post($product_data);

        //insert to custom meta
        update_post_meta($product_id, '_regular_price', round($_product->Price->Value,2));
        update_post_meta($product_id, '_price', round($_product->Price->Value,2));
        update_post_meta($product_id, '_weight', $_product->Weight);
        update_post_meta($product_id, '_visibility', 'visible');
        update_post_meta($product_id, '_stock_status', 'instock');

        // SKU dislayed is not the Supplier's SKU
        update_post_meta($product_id, '_InternalSku', $_product->SKU);
        update_post_meta($product_id, '_sku', 'STL' . sprintf("%07d",$product_id));

        foreach($_product->WebCategories as $cat){
            wp_set_post_terms( $product_id, $cat->Name, 'product_cat' );
        }
        if(!empty($_product->Images)){
            update_post_meta($product_id, '_product_feature_image', $_product->Images[0]->FullUrl);
        }
        update_post_meta($product_id, 'ProductSource', 'dbxstl');
        update_post_meta($product_id, 'OnHand', $_product->OnHand);
        update_post_meta($product_id, 'Status', $_product->Status);
        update_post_meta($product_id, 'Orderable', $_product->Orderable);
        update_post_meta($product_id, 'IsOnPriceList', $_product->IsOnPriceList);
        update_post_meta($product_id, 'UnitOfSale', $_product->UnitOfSale);
        update_post_meta($product_id, 'GramWeight', $_product->GramWeight);
        update_post_meta($product_id, 'LeadTime', $_product->LeadTime);
        //update_post_meta($product_id, 'StoneMapImagee', $_product->StoneMapImage);
        update_post_meta($product_id, 'ReadyToWear', $_product->ReadyToWear);
        update_post_meta($product_id, 'AGTA', $_product->AGTA);
        update_post_meta($product_id, 'ProductType', $_product->ProductType);
        update_post_meta($product_id, 'DescriptiveElementGroup', serialize( $_product->DescriptiveElementGroup ) );
        //update_post_meta($product_id, 'SetWith', serialize( $_product->SetWith ));
        update_post_meta($product_id, 'MadeWith', serialize( $_product->MadeWith ));
        update_post_meta($product_id, 'GroupImages', serialize( $_product->GroupImages ));*/
        list($product_id,$type) = import_product($product_id);
        $productData = get_post($product_id);
        if($product_id && $type == 'import'){
            $error->add('import_prid_'.$product_id,sprintf('<div class="updated"><p>Import Product <strong>%s</strong> Success!</p></div>',$productData->post_title));
        }elseif($product_id && $type == 'imported'){
            $error->add('import_prid_'.$product_id,sprintf('<div class="error"><p>This <strong>%s</strong>Error: Already imported!!!</p></div>',$productData->post_title));
        }
        switch ($_POST['save']) {
            case __('Import Product'):
                if($error->get_error_messages()){
                    foreach ($error->get_error_messages() as $rows):
                        echo $rows;
                    endforeach;
                }
                break;
            case __('Import Product & Edit'):
                if($error->get_error_messages()){
                    foreach ($error->get_error_messages() as $rows):
                        echo $rows;
                    endforeach;
                }
                if($product_id && $type == 'import'){
                    echo '<meta http-equiv="refresh" content="1;'.admin_url("/post.php?post=".$product_id."&action=edit").'">';
                }
                break;
        }
    }

    //print("<pre>");print_r($rows);print("</pre>");
    print '<div class="wrap">';
    print '<h2>'. __('Import Stuller Product') .'</h2>';
    print '<form name="post" action="" method="post" id="post">';
    print '<div id="poststuff">';
    print '<div id="post-body" class="metabox-holder columns-2">';

    #- Right Colomn
    print '<div id="postbox-container-1" class="postbox-container">';
    //if($row->row_status == 'avail'){
        print '<input type="submit" class="button save_order button-primary tips" name="save" value="' . __('Import Product') . '"><br/><br/>';
        print '<input type="submit" class="button save_order button-primary tips" name="save" value="' . __('Import Product & Edit') . '"><br/>';
    //}
    print '</div>';

    #- Left Colomn
    print '<div id="postbox-container-2" class="postbox-container">';
    print '<div id="normal-sortables" class="meta-box-sortables">';
    print '<div class="inside">';
    print '<div class="panel">';

    print '<h2>'. __('Product Details').'</h2>';

    print '<table class="form-table">';
    print '<tbody>';

    print '<tr><th scope="row"><label for="">'. __('Protuct Type:').'</label></th><td> '. $_product->ProductType .'</td></tr>';
    print '<tr><th scope="row"><label for="">'. __('Product  ID:').'</label></th><td> '. $row->product_id .'</td></tr>';
    print '<tr><th scope="row"><label for="">'. __('product_code:').'</label></th><td> '. $row->product_code .'</td></tr>';
    print '<tr><th scope="row"><label for="">'. __('SKU:').'</label></th><td> '. $_product->SKU .'</p>';

    print '<tr><th scope="row"><label for="">'. __('ReadyToWear:').'</label></th><td> '. ($_product->ReadyToWear?'Yes':'No') .'</td></tr>';
    print '<tr><th scope="row"><label for="">'. __('CreationDate:').'</label></th><td> '. $_product->CreationDate .'</td></tr>';
    print '<tr><th scope="row"><label for="">'. __('date_added:').'</label></th><td> '. $row->date_added .'</td></tr>';
    print '<tr><th scope="row"><label for="">'. __('row_status:').'</label></th><td> '. $row->row_status .'</td></tr>';

    print '<tr><th scope="row"><label for="">'
        . __('Image')
        . '</label></th><td>'
        . ' ' . ($row->Image1 != '' ? '<img width=150 height=150 src="'.$row->Image1.'">' : '&nbsp;') .''
        . ' ' . ($row->Image2 != '' ? '<img width=150 height=150 src="'.$row->Image2.'">' : '&nbsp;') .''
        . ' ' . ($row->Image3 != '' ? '<img width=150 height=150 src="'.$row->Image3.'">' : '&nbsp;') .''
        . '</td>'
        . '</tr>';


    print '<tr><th scope="row"><label for="">'
        . __('GroupImage1')
        . '</label></th><td>'
        . ' ' . ($row->GroupImage1 != '' ? '<img width=150 height=150 src="'.$row->GroupImage1.'">' : '&nbsp;') .''
        . ' ' . ($row->GroupImage2 != '' ? '<img width=150 height=150 src="'.$row->GroupImage2.'">' : '&nbsp;') .''
        . ' ' . ($row->GroupImage3 != '' ? '<img width=150 height=150 src="'.$row->GroupImage3.'">' : '&nbsp;') .''
        . '</td>'
        . '</tr>';

    print '<tr><th scope="row"><label for="">'. __('Description:').'</label></th><td> '. $_product->Description .'</td></tr>';
    print '<tr><th scope="row"><label for="">'. __('Short Description:').'</label></th><td> '. $_product->ShortDescription .'</td></tr>';
    print '<tr><th scope="row"><label for="">'. __('Group Description:').'</label></th><td> '. $_product->GroupDescription .'</td></tr>';





    print '<tr><th scope="row"><label for="">'. __('Video:').'</label></th><td> '. $_product->Video .'</td></tr>';
    print '<tr><th scope="row"><label for="">'. __('VideoType:').'</label></th><td> '. $_product->VideoType .'</td></tr>';
    print '<tr><th scope="row"><label for="">'. __('GroupVideo:').'</label></th><td> '. $_product->GroupVideo .'</td></tr>';
    print '<tr><th scope="row"><label for="">'. __('GroupVideoType:').'</label></th><td> '. $_product->GroupVideoType .'</td></tr>';


    print '<tr><th scope="row"><label for="">'. __('Collection:').'</label></th><td> '. $_product->Collection .'</td></tr>';
    print '<tr><th scope="row"><label for="">'. __('OnHand:').'</label></th><td> '. $_product->OnHand .'</td></tr>';
    print '<tr><th scope="row"><label for="">'. __('Status:').'</label></th><td> '. $_product->Status .'</td></tr>';
    print '<tr><th scope="row"><label for="">'. __('Price:').'</label></th><td> '. number_format($_product->Price->Value, 2) .' '.$_product->Price->CurrencyCode.'</td></tr>';
    print '<tr><th scope="row"><label for="">'. __('UnitOfSale:').'</label></th><td> '. $_product->UnitOfSale .'</td></tr>';
    print '<tr><th scope="row"><label for="">'. __('Weight:').'</label></th><td> '. $_product->Weight .'</td></tr>';
    print '<tr><th scope="row"><label for="">'. __('WeightUnitOfMeasure:').'</label></th><td> '. $_product->WeightUnitOfMeasure .'</td></tr>';
    print '<tr><th scope="row"><label for="">'. __('GramWeight:').'</label></th><td> '. $_product->GramWeight .'</td></tr>';
    print '<tr><th scope="row"><label for="">'. __('RingSizable:').'</label></th><td> '. $_product->RingSizable .'</td></tr>';
    print '<tr><th scope="row"><label for="">'. __('RingSize:').'</label></th><td> '. $_product->RingSize .'</td></tr>';
    print '<tr><th scope="row"><label for="">'. __('RingSizeType:').'</label></th><td> '. $_product->RingSizeType .'</td></tr>';
    print '<tr><th scope="row"><label for="">'. __('LeadTime:').'</label></th><td> '. $_product->LeadTime .'</td></tr>';

    print '<tr><th scope="row"><label for="">'. __('DescriptiveElementGroup:').'</label></th><td> '. $_product->DescriptiveElementGroup->GroupName .'</td></tr>';
    foreach ($_product->DescriptiveElementGroup->DescriptiveElements as $element) {
        print '<tr><th scope="row"><label for="">'. __('DescriptiveElementName:').'</label></th><td> '. $element->Name .'</td></tr>';
        print '<tr><th scope="row"><label for="">'. __('DescriptiveElementValue:').'</label></th><td> '. $element->DisplayValue .'</td></tr>';
    }

    print '</tbody>';
    print '</table>';

    print '</div>';
    print '</div>';
    print '</div>';
    print '</div>';

    print '</div>';
    print '</div>';
    print '<div class="clear"></div>';
    print '</form>';
    print '</div>';

}
