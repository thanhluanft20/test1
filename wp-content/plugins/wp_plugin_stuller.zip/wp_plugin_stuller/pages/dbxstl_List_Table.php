<?php
/*************************** LOAD THE BASE CLASS *******************************
 */
if(!class_exists('WP_List_Table')){
    require_once( ABSPATH . 'wp-admin/includes/class-wp-list-table.php' );
}

/************************** CREATE A PACKAGE CLASS *****************************
 *******************************************************************************
 * Create a new list table package that extends the core WP_List_Table class.
 * WP_List_Table contains most of the framework for generating the table, but we
 * need to define and override some methods so that our data can be displayed
 * exactly the way we need it to be.
 *
 * To display this example on a page, you will first need to instantiate the class,
 * then call $yourInstance->prepare_items() to handle any data manipulation, then
 * finally call $yourInstance->display() to render the table to the page.
 *
 * Our theme for this list table is going to be movies.
 */
class dbxstl_List_Table extends WP_List_Table {

    /** ************************************************************************
     * Normally we would be querying data from a database and manipulating that
     * for use in your list table. For this example, we're going to simplify it
     * slightly and create a pre-built array. Think of this as the data that might
     * be returned by $wpdb->query().
     *
     * @var array
     **************************************************************************/
    /*var $example_data = array(
        array(
            'ID'        => 1,
            'title'     => '300',
            'rating'    => 'R',
            'director'  => 'Zach Snyder'
        ),
        array(
            'ID'        => 2,
            'title'     => 'Eyes Wide Shut',
            'rating'    => 'R',
            'director'  => 'Stanley Kubrick'
        ),
        array(
            'ID'        => 3,
            'title'     => 'Moulin Rouge!',
            'rating'    => 'PG-13',
            'director'  => 'Baz Luhrman'
        ),
        array(
            'ID'        => 4,
            'title'     => 'Snow White',
            'rating'    => 'G',
            'director'  => 'Walt Disney'
        ),
        array(
            'ID'        => 5,
            'title'     => 'Super 8',
            'rating'    => 'PG-13',
            'director'  => 'JJ Abrams'
        ),
        array(
            'ID'        => 6,
            'title'     => 'The Fountain',
            'rating'    => 'PG-13',
            'director'  => 'Darren Aronofsky'
        ),
        array(
            'ID'        => 7,
            'title'     => 'Watchmen',
            'rating'    => 'R',
            'director'  => 'Zach Snyder'
        )
    );*/

    function __construct(){
        global $status, $page;

        //Set parent defaults
        parent::__construct( array(
            'singular'  => 'product',     //singular name of the listed records
            'plural'    => 'products',    //plural name of the listed records
            'ajax'      => false        //does this table support ajax?
        ) );

    }
    /** ************************************************************************
     * For more detailed insight into how columns are handled, take a look at
     * WP_List_Table::single_row_columns()
     *
     * @param array $item A singular item (one full row's worth of data)
     * @param array $column_name The name/slug of the column to be processed
     * @return string Text or HTML to be placed inside the column <td>
     **************************************************************************/
    function column_default($item, $column_name){
        switch($column_name){
            case 'image':
            case 'product_code':
            case 'sku':
            case 'product_type':
            case 'description':
            case 'status':
            case 'date_added':
                return $item[$column_name];
            default:
                return print_r($item,true); //Show the whole array for troubleshooting purposes
        }
    }
    /** ************************************************************************
     * @see WP_List_Table::::single_row_columns()
     * @param array $item A singular item (one full row's worth of data)
     * @return string Text to be placed inside the column <td> (movie title only)
     **************************************************************************/
    function column_title($item){

        //Build row actions
        $actions = array(
            'edit'      => sprintf('<a href="?page=%s&action=%s&product=%s">Edit</a>',$_REQUEST['page'],'edit',$item['ID']),
            'delete'    => sprintf('<a href="?page=%s&action=%s&product=%s">Delete</a>',$_REQUEST['page'],'delete',$item['ID']),
        );

        //Return the title contents
        return sprintf('%1$s <span style="color:silver">(id:%2$s)</span>%3$s',
            /*$1%s*/ $item['image'],
            /*$2%s*/ $item['ID'],
            /*$3%s*/ $this->row_actions($actions)
        );
    }


    /** ************************************************************************
     * @see WP_List_Table::::single_row_columns()
     * @param array $item A singular item (one full row's worth of data)
     * @return string Text to be placed inside the column <td> (movie title only)
     **************************************************************************/
    function column_cb( $item ){
        return sprintf(
            '<input type="checkbox" name="%1$s[]" value="%2$s" />',
            /*$1%s*/ $this->_args['singular'],  //Let's simply repurpose the table's singular label ("movie")
            /*$2%s*/ $item['ID']                //The value of the checkbox should be the record's id
        );
    }

    function get_columns(){
        $columns = array(
            'cb'            => '<input type="checkbox" />', //Render a checkbox instead of text
            'image'         => 'Image',
            'product_code'  => 'Product Code',
            'sku'           => 'SKU',
            'product_type'  => 'Product Type',
            'description'   => 'Description',
            'status'        => 'Status',
            'date_added'    => 'Date Added',
        );
        return $columns;
    }
    /** ************************************************************************
     * @return array An associative array containing all the columns that should be sortable: 'slugs'=>array('data_values',bool)
     **************************************************************************/
    function get_sortable_columns() {
        $sortable_columns = array(
            'product_type'=> array('product_type',false),       //true means it's already sorted
            'date_added'  => array('date_added',false)
        );
        return $sortable_columns;
    }

    function get_bulk_actions() {
        $actions = array(
            'delete'    => 'Delete'
        );
        return $actions;
    }

    function process_bulk_action() {
        //Detect when a bulk action is being triggered...
        if( 'delete'===$this->current_action() ) {
            wp_die('Items deleted (or they would be if we had items to delete)!');
        }
    }
    /** ************************************************************************
     * @global WPDB $wpdb
     * @uses $this->_column_headers
     * @uses $this->items
     * @uses $this->get_columns()
     * @uses $this->get_sortable_columns()
     * @uses $this->get_pagenum()
     * @uses $this->set_pagination_args()
     **************************************************************************/
    function prepare_items() {
        global $wpdb;
        $per_page = 50;

        $columns = $this->get_columns();
        $hidden = array();
        $sortable = $this->get_sortable_columns();

        $this->_column_headers = array($columns, $hidden, $sortable);

        $this->process_bulk_action();

        /**
         * Instead of querying a database, we're going to fetch the example data
         * property we created for use in this plugin. This makes this example
         * package slightly different than one you might build on your own. In
         * this example, we'll be using array manipulation to sort and paginate
         * our data. In a real-world implementation, you will probably want to
         * use sort and pagination data to build a custom query instead, as you'll
         * be able to use your precisely-queried data immediately.

        $data = $this->example_data;*/
        $tableProducts = $wpdb->prefix . "dbxstl_products";

        $validGroups = array(
            "avail" => 1,
            "new" => 1,
            "selected" => 1,
            "deleted" => 1,
            "total" => 1,
        );

        $currentGroup = '';
        $currentType = '';
        if(isset($_GET['type'])){
            $currentType = mysql_real_escape_string($_GET['type']);
        }

        if(isset($_GET['group'])){
            $currentGroup = $_GET['group'];
        }
        if(!isset($validGroups[$currentGroup])){
            $currentGroup = 'avail';
        }
        $query="from $tableProducts ";

        $where = 'where 1=1 ';
        if($currentGroup != 'total'){
            $query .= " $where and row_status = '$currentGroup'";
            $where = '';
        }
        if($currentType){
            $query .= " $where and ProductType = '$currentType'";
            $where = '';
        }
        $query .= " order by Description ";

        $limitPerPage = $per_page;
        $page = isset( $_GET['cpage'] ) ? abs( (int) $_GET['cpage'] ) : 1;
        $limitStart = (($page - 1) * $limitPerPage);

        $data = $wpdb->get_results('select * ' . $query . " limit $limitStart,$limitPerPage ");

        function usort_reorder($a,$b){
            $orderby = (!empty($_REQUEST['orderby'])) ? $_REQUEST['orderby'] : 'image'; //If no sort, default to title
            $order = (!empty($_REQUEST['order'])) ? $_REQUEST['order'] : 'asc'; //If no order, default to asc
            $result = strcmp($a[$orderby], $b[$orderby]); //Determine sort order
            return ($order==='asc') ? $result : -$result; //Send final sort direction to usort
        }
        usort($data, 'usort_reorder');


        /***********************************************************************
         * ---------------------------------------------------------------------
         * vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv
         *
         * In a real-world situation, this is where you would place your query.
         *
         * For information on making queries in WordPress, see this Codex entry:
         * http://codex.wordpress.org/Class_Reference/wpdb
         *
         * ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
         * ---------------------------------------------------------------------
         **********************************************************************/

        $current_page = $this->get_pagenum();

        $total_items = count($data);

        $data = array_slice($data,(($current_page-1)*$per_page),$per_page);

        $this->items = $data;

        $this->set_pagination_args( array(
            'total_items' => $total_items,                  //WE have to calculate the total number of items
            'per_page'    => $per_page,                     //WE have to determine how many items to show on a page
            'total_pages' => ceil($total_items/$per_page)   //WE have to calculate the total number of pages
        ) );
    }
}
/** *************************** RENDER TEST PAGE ********************************
 *******************************************************************************
 * This function renders the admin page and the example list table. Although it's
 * possible to call prepare_items() and display() from the constructor, there
 * are often times where you may need to include logic here between those steps,
 * so we've instead called those methods explicitly. It keeps things flexible, and
 * it's the way the list tables are used in the WordPress core.
 */
function dbxstl_render_list_page(){

    //Create an instance of our package class...
    $productListTable = new dbxstl_List_Table();
    //Fetch, prepare, sort, and filter our data...
    $productListTable->prepare_items();

    ?>
    <div class="wrap">
        <!--
        <h2>List Table Test</h2>-->
        <!-- Forms are NOT created automatically, so you need to wrap the table in one to use features like bulk actions -->
        <form id="products-filter" method="get">
            <!-- For plugins, we also need to ensure that the form posts back to our current page -->
            <input type="hidden" name="page" value="<?php echo $_REQUEST['page'] ?>" />
            <!-- Now we can render the completed list table -->
            <?php $productListTable->display() ?>
        </form>

    </div>
<?php
}