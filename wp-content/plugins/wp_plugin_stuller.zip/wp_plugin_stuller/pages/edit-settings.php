<?php

if(!defined('dbxstl_preload')) {
    echo 'error';
    exit;
}

$listFreq = array(
    'Manually' => 0,
    'Monday' => 1,
    'Tuesday' => 2,
    'Wednesday' => 3,
    'Thursday' => 4,
    'Friday' => 5,
    'Saturday' => 6,
    'Sunday' => 7,
);

echo '<form method="post" action="admin-post.php">';
settings_fields('dbxstl_options_group');
do_settings_sections('dbxstl_options_group');

echo '<input type="hidden" name="action" value="save_dbxstl_options" />';
echo '<table class="form-table">
        <tr valign="top">
        <th scope="row">Stuller developer username</th>
        <td><input type="text" name="dbxstl_user" value="' . get_option('dbxstl_user') . '" /></td>
        </tr>
        
        <tr valign="top">
        <th scope="row">Password</th>
        <td><input type="password" name="dbxstl_pass" value="' . get_option('dbxstl_pass'), '" /></td> 
        </tr>

        <tr valign="top">
        <th scope="row">Update Frequency</th>
        <td>';

echo '<select name="dbxstl_freq" id="dbxstl_freq">';
foreach ($listFreq as $day => $day_id) {
    echo "<option value=\"$day_id\"" . selected(get_option('dbxstl_freq'), $day_id) . ">$day</option>";
}
echo '</select>';

echo "&nbsp;&nbsp;<a href=\"?page=dbxstl-menu-settings&act=update\">Update Now (VERY LONG PROCESS)</a>";
echo '        </td>
        </tr>
    </table>';

submit_button();
echo '</form>';
