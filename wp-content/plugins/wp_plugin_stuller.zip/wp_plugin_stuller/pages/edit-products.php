<?php
if(!defined('dbxstl_preload')) {
    echo 'error';
    exit;
}

if(isset($_GET['act'])){
    $act = $_GET['act'];
}else{
    $act = 'list';
}



switch ($act) {
    case 'choose':
    case 'edit':
        require(dirname(__FILE__) ."/edit-products-$act.php");
        break;

    default:
        require(dirname(__FILE__) ."/edit-products-list.php");
        break;
}