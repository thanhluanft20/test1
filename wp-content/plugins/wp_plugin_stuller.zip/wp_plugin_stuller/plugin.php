<?php

/*
  Plugin Name: DataboxNet Stuller
  Plugin URI: http://plugins.databox.net/stuller
  Description: Manage your Stuller product
  Version: 0.1
  Author: Databox Informatique
  Author URI: http://databox.net
  License: GPL2
  ShortInternalName: dbxstl
 */

global $wpdb;

//test commit #8
define('DBXSTL_VERSION', '0.1.0');
define('DBXSTL_DB_VERSION', '0.1.09');
add_filter('woocommerce_placeholder_img_src', 'custom_woocommerce_placeholder_img_src');
function custom_woocommerce_placeholder_img_src($src){
    global $post;
    $imgurl = get_post_meta($post->ID,'_product_feature_image',true);
    return (!(empty($imgurl))) ? $imgurl : $src;
}
/*
 * Add data into dbxstl_order
 */
add_action( 'woocommerce_order_status_changed', 'add_data_dbxstl_order' , 3);
function add_data_dbxstl_order($order_id){

    $order = new WC_Order( $order_id );
    //Get items in order
    if ( $order->get_items() ) {
        foreach ( $order->get_items() as $item ) {;
            $lost_list = array();
            $_product       = $order->get_product_from_item( $item );
            $ProductSource        = get_post_meta($_product->id, "ProductSource", true );
            /*
             * Check Product Source And Insert Into Table dbxstl_order
             */
            if(!empty($ProductSource) && $ProductSource == 'dbxstl'){
                insert_dbxstl_order($item,$order_id);
            }
        }
    }
}
/*
 * Insert Order Table dbxstl_order
 */
function insert_dbxstl_order($item,$order_id){
    global $wpdb;
    $dataorder = array(
        'order_id' => $order_id,
        'order_status' => 'waiting',
    );
    $dataorderDetail = array(
        'order_id' => $order_id,
        'product_id' => $item['product_id'],
        'quantity' => $item['qty'],
        'blob' => '',
    );
    $orderID = xstl_check_product_order($order_id);
    if($orderID){
        $dataorder['id'] = $orderID;
    }
    $orderdetailID = xstl_check_product_order_detail($order_id,$item['product_id']);
    if($orderdetailID){
        $dataorderDetail['id'] = $orderdetailID;
    }
    $tableorder = $wpdb->prefix . "dbxstl_orders";
    $tableorderDetail = $wpdb->prefix . "dbxstl_orders_detail";
    $wpdb->insert( $tableorder, $dataorder );
    $wpdb->insert( $tableorderDetail, $dataorderDetail );
}
/*
 * Check Product Exists
 */
function xstl_check_product_order($order_id){
    global $wpdb;
    $table = $wpdb->prefix . "dbxstl_orders";
    $return = $wpdb->get_var("SELECT id FROM `{$table}` WHERE `order_id` = '{$order_id}'");
    return $return;
}
function xstl_check_product_order_detail($order_id = 0,$product_id = 0){
    global $wpdb;
    $table = $wpdb->prefix . "dbxstl_orders_detail";
    $return = $wpdb->get_var("SELECT id FROM `{$table}` WHERE `order_id` = '{$order_id}' AND `product_id` = '{$product_id}'");
    return $return;
}

if (is_admin()) {
    require_once(dirname(__FILE__) . '/dbxstl-config.php');
    require_once(dirname(__FILE__) . '/dbxstl-functions.php');


    load_plugin_textdomain('dbxstl', false, basename(dirname(__FILE__)) . '/lang');

    add_action('admin_menu', 'register_dbxstl_menu_page');
    add_action('admin_init', 'register_dbxstl_setting');

    register_activation_hook(__FILE__, 'dbxstl_install');

    function add_query_vars_filter($vars)
    {
        $vars = array("act");
        return $vars;
    }

    add_filter('query_vars', 'add_query_vars_filter');


    function process_dbxstl_options()
    {
        // Check that user has proper security level
        if (!current_user_can('manage_options'))
            wp_die('Not allowed, sorry');


        $listOptions = array(
            'dbxstl_user',
            'dbxstl_pass',
            'dbxstl_freq',
            'dbxstl_cats',
            'dbxstl_catlists',
            'dbxstl_page',
        );

        $listCheckOptions = array(
            'dbxstl_check1',
        );

        // Get all options old and new
        $options = array();
        foreach ($listOptions as $option_name) {
            $options[$option_name] = get_option($option_name);
        }

        //
        foreach ($listOptions as $option_name) {
            if (isset($_POST[$option_name])) {
                $options[$option_name] = sanitize_text_field($_POST[$option_name]);
            }
        }

        foreach ($listCheckOptions as $option_name) {
            if (isset($_POST[$option_name])) {
                $options[$option_name] = true;
            } else {
                $options[$option_name] = false;
            }
        }

        // Store the new options
        foreach ($listOptions as $option_name) {
            update_option($option_name, $options[$option_name]);
        }
        foreach ($listCheckOptions as $option_name) {
            update_option($option_name, $options[$option_name]);
        }


        // Redirect the page to the configuration form that was
        // processed
        wp_redirect(add_query_arg('page', 'dbxstl-menu',
            admin_url() . '/admin.php'));
        exit;
    }

    function register_dbxstl_menu_page()
    {
        add_menu_page(
            'Manage Stuller',
            'Manage Stuller',
            'manage_options',
            'dbxstl-menu',
            'dbxstl_menu_page',
            '',
            61
        );

        add_submenu_page(
            'dbxstl-menu',
            'Stuller Products',
            __('Settings', 'dbxstl'),
            'manage_options',
            'dbxstl-menu-settings',
            'dbxstl_menu_page'
        );

        add_submenu_page(
            'dbxstl-menu',
            'Stuller Products',
            __('Products', 'dbxstl'),
            'manage_options',
            'dbxstl-menu-products',
            'dbxstl_menu_page'
        );

        add_submenu_page(
            'dbxstl-menu',
            'Stuller Products',
            __('Orders', 'dbxstl'),
            'manage_options',
            'dbxstl-menu-orders',
            'dbxstl_menu_page'
        );

    }

    function register_dbxstl_setting()
    {
        register_setting('dbxstl_options_group', 'dbxstl_option_username');
        register_setting('dbxstl_options_group', 'dhstuller_username');
        register_setting('dbxstl_options_group', 'dhstuller_password');
        add_action('admin_post_save_dbxstl_options', 'process_dbxstl_options');
        wp_enqueue_style('dbxstl-css', plugins_url('pages/dbxstl.css', __FILE__));
    }


    function dbxstl_menu_page()
    {
        if (isset($_GET['act']) && ($_GET['act'] == 'update')) {
            dbxstlStullerLoad();
            //print "x"; exit;
            wp_redirect(add_query_arg('page', 'dbxstl-menu-settings', admin_url() . '/admin.php'));
            // exit;
        }

        $screenInfo = get_current_screen();
        $current = preg_replace('/.*\-/', '', $screenInfo->id);

        if ($current == 'menu') {
            $current = 'products';
        }
        if (!get_option('dbxstl_user')) {
            $current = 'settings';
        }

        $tabs = array(
            'settings' => __('Settings', 'dbxstl'),
            'products' => __('Products', 'dbxstl'),
            'orders' => __('Orders', 'dbxstl'),
        );
        $nonTabs = array(
            'update' => 1,
        );

        if (!isset($tabs[$current]) && !isset($nonTabs[$current])) {
            $current = 'products';
        }


        $links = array();
        foreach ($tabs as $tab => $name) {
            if ($tab == $current) :
                $links[] = '<a class="nav-tab nav-tab-active" href="' . admin_url() . "admin.php?page=dbxstl-menu-" . $tab . '">' . $name . '</a>';
            else :
                $links[] = '<a class="nav-tab" href="' . admin_url() . "admin.php?page=dbxstl-menu-" . $tab . '">' . $name . '</a>';
            endif;
        }

        echo '<h2 class="nav-tab-wrapper">';
        foreach ($links as $link)
            echo $link;
        echo '</h2>';

        print '<div class="wrap">';


        // print(dirname(__FILE__) ."/pages/edit-$current.php");
        define('dbxstl_preload', 1);
        //print ('<pre>' . "($current)");
        //print_r(get_current_screen());
        //print ('</pre>');
        require(dirname(__FILE__) . "/pages/edit-$current.php");

        echo '</div>';
    }


    function dbxstl_install()
    {
        global $wpdb;
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        $tableRaw = $wpdb->prefix . "dbxstl_raw";
        $tableProducts = $wpdb->prefix . "dbxstl_products";
        $tableOrders = $wpdb->prefix . "dbxstl_orders";
        $tableOrdersDetail = $wpdb->prefix . "dbxstl_orders_detail";

        $sqlRaw = "CREATE TABLE `$tableRaw` (
              `Sku` varchar(255) DEFAULT NULL,
              `Description` varchar(255) DEFAULT NULL,
              `ShortDescription` varchar(255) DEFAULT NULL,
              `GroupDescription` varchar(255) DEFAULT NULL,
              `MerchandisingCategory1` varchar(255) DEFAULT NULL,
              `MerchandisingCategory2` varchar(255) DEFAULT NULL,
              `MerchandisingCategory3` varchar(255) DEFAULT NULL,
              `MerchandisingCategory4` varchar(255) DEFAULT NULL,
              `MerchandisingCategory5` varchar(255) DEFAULT NULL,
              `ProductType` varchar(255) DEFAULT NULL,
              `Collection` varchar(255) DEFAULT NULL,
              `OnHand` varchar(255) DEFAULT NULL,
              `Status` varchar(255) DEFAULT NULL,
              `Price` varchar(255) DEFAULT NULL,
              `UnitOfSale` varchar(255) DEFAULT NULL,
              `Weight` varchar(255) DEFAULT NULL,
              `WeightUnitOfMeasure` varchar(255) DEFAULT NULL,
              `GramWeight` varchar(255) DEFAULT NULL,
              `RingSizable` varchar(255) DEFAULT NULL,
              `RingSize` varchar(255) DEFAULT NULL,
              `RingSizeType` varchar(255) DEFAULT NULL,
              `LeadTime` varchar(255) DEFAULT NULL,
              `DescriptiveElementGroup` varchar(255) DEFAULT NULL,
              `DescriptiveElementName1` varchar(255) DEFAULT NULL,
              `DescriptiveElementValue1` varchar(255) DEFAULT NULL,
              `DescriptiveElementName2` varchar(255) DEFAULT NULL,
              `DescriptiveElementValue2` varchar(255) DEFAULT NULL,
              `DescriptiveElementName3` varchar(255) DEFAULT NULL,
              `DescriptiveElementValue3` varchar(255) DEFAULT NULL,
              `DescriptiveElementName4` varchar(255) DEFAULT NULL,
              `DescriptiveElementValue4` varchar(255) DEFAULT NULL,
              `DescriptiveElementName5` varchar(255) DEFAULT NULL,
              `DescriptiveElementValue5` varchar(255) DEFAULT NULL,
              `DescriptiveElementName6` varchar(255) DEFAULT NULL,
              `DescriptiveElementValue6` varchar(255) DEFAULT NULL,
              `DescriptiveElementName7` varchar(255) DEFAULT NULL,
              `DescriptiveElementValue7` varchar(255) DEFAULT NULL,
              `DescriptiveElementName8` varchar(255) DEFAULT NULL,
              `DescriptiveElementValue8` varchar(255) DEFAULT NULL,
              `DescriptiveElementName9` varchar(255) DEFAULT NULL,
              `DescriptiveElementValue9` varchar(255) DEFAULT NULL,
              `DescriptiveElementName10` varchar(255) DEFAULT NULL,
              `DescriptiveElementValue10` varchar(255) DEFAULT NULL,
              `DescriptiveElementName11` varchar(255) DEFAULT NULL,
              `DescriptiveElementValue11` varchar(255) DEFAULT NULL,
              `DescriptiveElementName12` varchar(255) DEFAULT NULL,
              `DescriptiveElementValue12` varchar(255) DEFAULT NULL,
              `DescriptiveElementName13` varchar(255) DEFAULT NULL,
              `DescriptiveElementValue13` varchar(255) DEFAULT NULL,
              `DescriptiveElementName14` varchar(255) DEFAULT NULL,
              `DescriptiveElementValue14` varchar(255) DEFAULT NULL,
              `DescriptiveElementName15` varchar(255) DEFAULT NULL,
              `DescriptiveElementValue15` varchar(255) DEFAULT NULL,
              `ReadyToWear` varchar(255) DEFAULT NULL,
              `Image1` varchar(255) DEFAULT NULL,
              `Image2` varchar(255) DEFAULT NULL,
              `Image3` varchar(255) DEFAULT NULL,
              `Video` varchar(255) DEFAULT NULL,
              `VideoType` varchar(255) DEFAULT NULL,
              `GroupImage1` varchar(255) DEFAULT NULL,
              `GroupImage2` varchar(255) DEFAULT NULL,
              `GroupImage3` varchar(255) DEFAULT NULL,
              `GroupVideo` varchar(255) DEFAULT NULL,
              `GroupVideoType` varchar(255) DEFAULT NULL,
              `CreationDate` varchar(255) DEFAULT NULL
            ) default charset=utf8";

        $sqlProducts = "CREATE TABLE `$tableProducts` (
              product_id int(11) unsigned NOT NULL AUTO_INCREMENT,
              `Sku` varchar(255) DEFAULT NULL,
              `Description` varchar(255) DEFAULT NULL,
              `ShortDescription` varchar(255) DEFAULT NULL,
              `GroupDescription` varchar(255) DEFAULT NULL,
              `MerchandisingCategory1` varchar(255) DEFAULT NULL,
              `MerchandisingCategory2` varchar(255) DEFAULT NULL,
              `MerchandisingCategory3` varchar(255) DEFAULT NULL,
              `MerchandisingCategory4` varchar(255) DEFAULT NULL,
              `MerchandisingCategory5` varchar(255) DEFAULT NULL,
              `ProductType` varchar(255) DEFAULT NULL,
              `Collection` varchar(255) DEFAULT NULL,
              `OnHand` varchar(255) DEFAULT NULL,
              `Status` varchar(255) DEFAULT NULL,
              `Price` decimal(10,2) not null default '0.00',
              `UnitOfSale` varchar(255) DEFAULT NULL,
              `Weight` varchar(255) DEFAULT NULL,
              `WeightUnitOfMeasure` varchar(255) DEFAULT NULL,
              `GramWeight` varchar(255) DEFAULT NULL,
              `RingSizable` varchar(255) DEFAULT NULL,
              `RingSize` varchar(255) DEFAULT NULL,
              `RingSizeType` varchar(255) DEFAULT NULL,
              `LeadTime` varchar(255) DEFAULT NULL,
              `DescriptiveElementGroup` varchar(255) DEFAULT NULL,
              `DescriptiveElementName1` varchar(255) DEFAULT NULL,
              `DescriptiveElementValue1` varchar(255) DEFAULT NULL,
              `DescriptiveElementName2` varchar(255) DEFAULT NULL,
              `DescriptiveElementValue2` varchar(255) DEFAULT NULL,
              `DescriptiveElementName3` varchar(255) DEFAULT NULL,
              `DescriptiveElementValue3` varchar(255) DEFAULT NULL,
              `DescriptiveElementName4` varchar(255) DEFAULT NULL,
              `DescriptiveElementValue4` varchar(255) DEFAULT NULL,
              `DescriptiveElementName5` varchar(255) DEFAULT NULL,
              `DescriptiveElementValue5` varchar(255) DEFAULT NULL,
              `DescriptiveElementName6` varchar(255) DEFAULT NULL,
              `DescriptiveElementValue6` varchar(255) DEFAULT NULL,
              `DescriptiveElementName7` varchar(255) DEFAULT NULL,
              `DescriptiveElementValue7` varchar(255) DEFAULT NULL,
              `DescriptiveElementName8` varchar(255) DEFAULT NULL,
              `DescriptiveElementValue8` varchar(255) DEFAULT NULL,
              `DescriptiveElementName9` varchar(255) DEFAULT NULL,
              `DescriptiveElementValue9` varchar(255) DEFAULT NULL,
              `DescriptiveElementName10` varchar(255) DEFAULT NULL,
              `DescriptiveElementValue10` varchar(255) DEFAULT NULL,
              `DescriptiveElementName11` varchar(255) DEFAULT NULL,
              `DescriptiveElementValue11` varchar(255) DEFAULT NULL,
              `DescriptiveElementName12` varchar(255) DEFAULT NULL,
              `DescriptiveElementValue12` varchar(255) DEFAULT NULL,
              `DescriptiveElementName13` varchar(255) DEFAULT NULL,
              `DescriptiveElementValue13` varchar(255) DEFAULT NULL,
              `DescriptiveElementName14` varchar(255) DEFAULT NULL,
              `DescriptiveElementValue14` varchar(255) DEFAULT NULL,
              `DescriptiveElementName15` varchar(255) DEFAULT NULL,
              `DescriptiveElementValue15` varchar(255) DEFAULT NULL,
              `ReadyToWear` varchar(255) DEFAULT NULL,
              `Image1` varchar(255) DEFAULT NULL,
              `Image2` varchar(255) DEFAULT NULL,
              `Image3` varchar(255) DEFAULT NULL,
              `Video` varchar(255) DEFAULT NULL,
              `VideoType` varchar(255) DEFAULT NULL,
              `GroupImage1` varchar(255) DEFAULT NULL,
              `GroupImage2` varchar(255) DEFAULT NULL,
              `GroupImage3` varchar(255) DEFAULT NULL,
              `GroupVideo` varchar(255) DEFAULT NULL,
              `GroupVideoType` varchar(255) DEFAULT NULL,
              `CreationDate` varchar(255) DEFAULT NULL,
              in_raw bool not null default 0,
              date_added date not null default '0000-00-00',
              row_status enum('selected','avail','deleted') not null default 'avail',
              `product_code` varchar(255) DEFAULT NULL,
              PRIMARY KEY (product_id),
              UNIQUE KEY (sku),
              UNIQUE KEY (product_code)
            )default charset=utf8";

        $sqlOrders = "CREATE TABLE IF NOT EXISTS `{$tableOrders}` (\n"
            . " `id` int(11) NOT NULL AUTO_INCREMENT,\n"
            . " `order_id` int(11) NOT NULL,\n"
            . " `order_status` varchar(255) NOT NULL,\n"
            . " PRIMARY KEY (`id`)\n"
            . ")default charset=utf8";
        $sqlOrderDetails = "CREATE TABLE IF NOT EXISTS `{$tableOrdersDetail}` (\n"
            . " `id` int(11) NOT NULL AUTO_INCREMENT,\n"
            . " `order_id` int(11) NOT NULL,\n"
            . " `product_id` int(11) NOT NULL,\n"
            . " `quantity` int(11) NOT NULL,\n"
            . " `blob` longtext,\n"
            . " PRIMARY KEY (`id`)\n"
            . ")default charset=utf8";

        dbDelta($sqlRaw);
        dbDelta($sqlProducts);
        dbDelta($sqlOrders);


        /*
         * Check Database Version To ALTER TABLE
         */
        $dbxstl_db_verstion = get_option("dbxstl_db_vertion");
        if(version_compare($dbxstl_db_verstion,'0.1.08','<=')){
            dbDelta($sqlOrderDetails);
            //add columns
            add_column_if_not_exist($tableOrders,'order_id','int(11) NOT NULL');
            add_column_if_not_exist($tableOrders,'product_id','int(11) NOT NULL',true);
            add_column_if_not_exist($tableOrders,'quantity','int(11) NOT NULL',true);
            add_column_if_not_exist($tableOrders,'order_status','int(11) NOT NULL');
            add_column_if_not_exist($tableOrders,'blob','VARCHAR(255) NULL',true);
        }
        add_option("dbxstl_db_version", DBXSTL_DB_VERSION);
    }
    function add_column_if_not_exist($db, $column, $column_attr = "VARCHAR( 255 ) NULL",$remove = false ){
        global $wpdb;
        $exists = false;
        $columns = $wpdb->query("show columns from $db");
        while($c = mysql_fetch_assoc($columns)){
            if($c['Field'] == $column){
                $exists = true;
                break;
            }
        }
        if(!$exists && !$remove){
            $wpdb->query("ALTER TABLE `$db` ADD `$column`  $column_attr");
        }elseif(!$exists && $remove){
            $wpdb->query("ALTER TABLE `$db` DROP COLUMN `$column`");
        }
    }
}
add_action('wp','setup_cron_job');
function setup_cron_job(){
    /*
         * SETUP CRONJOB
         */
    if ( ! wp_next_scheduled( 'dbxstl_update_status_order_cronjob' ) ) {
        wp_schedule_event( time(), 'ten_m', 'dbxstl_update_status_order_cronjob');
    }
}
/*
 * ADD CRONJOB HOOK
 */
add_action( 'dbxstl_update_status_order_cronjob', 'dbxstl_update_status_order_cronjob_process' );
function dbxstl_update_status_order_cronjob_process() {
    global $wpdb;
    $tableOrders = $wpdb->prefix . "dbxstl_orders";
    $sql = "SELECT DISTINCT `order_id` FROM {$tableOrders} WHERE `order_status` = 'waiting' OR `order_status` = ''";
    $results = $wpdb->get_results($sql);
    foreach($results as $rows){
        $term_list = wp_get_object_terms($rows->order_id, 'shop_order_status');
        $flag = false;
        foreach($term_list as $row){
            $wpdb->update($tableOrders,array('order_status' => $row->slug),array('order_id' => $rows->order_id));
            $flag = true;
        }
        /*
         * UPDATE ORDER STATUS INTO TABLE dbxstl_orders
         */
        if($flag){
            do_action('dbxstl_updated_order_status',$rows->order_id);
        }
    }
}
add_filter( 'cron_schedules', 'cron_add_ten_m' );

function cron_add_ten_m( $schedules ) {
    $schedules['ten_m'] = array(
        'interval' => 600,
        'display' => __( 'Ten' )
    );
    return $schedules;
}
/*
 * CLEAR CRONJOB
 */
register_deactivation_hook( __FILE__, 'dbxstl_deactivation' );
function dbxstl_deactivation() {
    wp_clear_scheduled_hook( 'dbxstl_update_status_order_cronjob' );
}


add_action('dbxstl_updated_order_status','dbxstl_updated_order_status_function');
function dbxstl_updated_order_status_function($order_id){
    if(class_exists("WC_Order")){
        $order = new WC_Order($order_id);
        /*
         * DATA EXAMPLE
         */
        $order_data = get_post($order_id);
        $billing_address = $order->get_billing_address();
        $shipping_address = $order->get_shipping_address();
        $data = array(
            "CustomerData" => array(
                "OrderNumber" => $order_id,
                "OrderDate" => $order_data->post_date_gmt,
                "EmailConfirmation" => array(
                    "FromAddress" => "sample string 1",
                    "SendOrderConfirmation" => true,
                    "SendShipmentConfirmation" => true,
                    "ToAddress" => "sample string 4"
                ),
                "ExtraAmount" => array(
                    "Label" => "sample string 1",
                    "Value" => "sample string 2"
                ),
                "FreightAmount" => 3.1,
                "TaxAmount" => 4.1,
                "Message1" => "sample string 5",
                "Message2" => "sample string 6",
                "AdditionalData" => array()
            ),
            "Contact" => array(
                "Name" => "sample string 1",
                "Phone" => "sample string 2",
                "EmailAddress" => "sample string 3"
            ),
            "Payment" => array(
                "CardNumber" => "sample string 1",
                "CardHolderName" => "sample string 2",
                "ExpirationDate" => "sample string 3",
                "Type" => "Terms"
            ),
            "ShipToAddress" => array(
                "Address" => array(
                    "Name" => $order->billing_first_name ." " .$order->billing_last_name,
                    "AddressLine1" => $billing_address['address_1'],
                    "AddressLine2" => $billing_address['address_2'],
                    "City" => $billing_address['city'],
                    "State" => $billing_address['state'],
                    "PostalCode" => $billing_address['postcode'],
                    "Province" => "sample string 7",
                    "Country" => $billing_address['country'],
                    "Phone" => $order->billing_phone
                ),
                "ShipComplete" => true,
                "ShipMethodType" => "UPS_NEXT_DAY",
                "RemovePricing" => true,
                "SignatureRequired" => true
            ),
            "BillToAddress" => array(
                "Address" => array(
                    "Name" => $order->shipping_first_name . " " . $order->shipping_last_name,
                    "AddressLine1" => $order->shipping_address_1,
                    "AddressLine2" => $order->shipping_address_2,
                    "City" => $order->shipping_city,
                    "State" => $order->shipping_state,
                    "PostalCode" => $order->shipping_postcode,
                    "Province" => "sample string 7",
                    "Country" => $order->shipping_country,
                    "Phone" => $order->billing_phone
                ),
                "SameAsShipTo" => true
            ),
            "Lines" => array(
                "Items" => array(),
                "Engravings" => array(
                    "EngravingLine" => array(
                        "LineLocation" => 1,
                        "Text" => "sample string 2"
                    ), array(
                        "LineLocation" => 1,
                        "Text" => "sample string 2"
                    )
                ),
                "Location" => 1,
                "EngravingType" => "sample string 2",
                "FontType" => "sample string 3",
                "FontSize" => "sample string 4",
                "FillOption" => "sample string 5",
                "FillColor" => "sample string 6"
            ,
                array(
                    "EngravingLine" => array(
                        "LineLocation" => 1,
                        "Text" => "sample string 2"
                    ), array(
                    "LineLocation" => 1,
                    "Text" => "sample string 2"
                )
                ),
                "Location" => 1,
                "EngravingType" => "sample string 2",
                "FontType" => "sample string 3",
                "FontSize" => "sample string 4",
                "FillOption" => "sample string 5",
                "FillColor" => "sample string 6"
            ,
                "EarringBack" => array(
                    "Number" => "sample string 1"
                ),
                "Chain" => array(
                    "Number" => "sample string 1"
                ),
                "Notes" => array(
                    "NoteType" => "Manufacturing",
                    "Text" => "sample string 1"
                ), array(
                    "NoteType" => "Manufacturing",
                    "Text" => "sample string 1"
                )
            ,
                "Number" => "sample string 1",
                "RingSize" => 2.0,
                "ChainLength" => 4,
                "Instructions" => "sample string 6",
                "AdditionalDescription" => "sample string 7",
                "RequestedShipDate" => "sample string 8"
            , array(
                    "Clasp" => array(
                        "Number" => "sample string 1"
                    ),
                    "Stones" => array(
                        "Location" => 1,
                        "Number" => "sample string 2",
                        "SerialNumber" => "sample string 3",
                        "IsCustomerStone" => true,
                        "CustomerStoneValue" => 5.0
                    ), array(
                        "Location" => 1,
                        "Number" => "sample string 2",
                        "SerialNumber" => "sample string 3",
                        "IsCustomerStone" => true,
                        "CustomerStoneValue" => 5.0
                    )
                ),
                "Engravings" => array(
                    "EngravingLine" => array(
                        "LineLocation" => 1,
                        "Text" => "sample string 2"
                    ), array(
                        "LineLocation" => 1,
                        "Text" => "sample string 2"
                    )
                ),
                "Location" => 1,
                "EngravingType" => "sample string 2",
                "FontType" => "sample string 3",
                "FontSize" => "sample string 4",
                "FillOption" => "sample string 5",
                "FillColor" => "sample string 6"
            ), array(
                "EngravingLine" => array(
                    "LineLocation" => 1,
                    "Text" => "sample string 2"
                ), array(
                    "LineLocation" => 1,
                    "Text" => "sample string 2"
                )
            ,
                "Location" => 1,
                "EngravingType" => "sample string 2",
                "FontType" => "sample string 3",
                "FontSize" => "sample string 4",
                "FillOption" => "sample string 5",
                "FillColor" => "sample string 6"
            )
        ,
            "EarringBack" => array(
                "Number" => "sample string 1"
            ),
            "Chain" => array(
                "Number" => "sample string 1"
            ),
            "Notes" => array(
                "NoteType" => "Manufacturing",
                "Text" => "sample string 1"
            ), array(
                "NoteType" => "Manufacturing",
                "Text" => "sample string 1"
            )
        ,
            "Number" => "sample string 1",
            "RingSize" => 2.0,
            "ChainLength" => 4,
            "Instructions" => "sample string 6",
            "AdditionalDescription" => "sample string 7",
            "RequestedShipDate" => "sample string 8"

        ,
            "Quantity" => 1,
            "ExtendedPrice" => 2.0,
            "Item" => "sample string 3",
            "Description" => "sample string 4",
            "BoxType" => "Black",
            "GiftWrap" => true,
            "BoxDescription" => "sample string 7",
            "Message" => "sample string 8",
            "LineNumber" => "sample string 9",
            "Source" => "sample string 10",
            "CustomerLineReference" => "sample string 11"
        , array(
                "Items" => array(
                    "Clasp" => array(
                        "Number" => "sample string 1"
                    ),
                    "Stones" => array(
                        "Location" => 1,
                        "Number" => "sample string 2",
                        "SerialNumber" => "sample string 3",
                        "IsCustomerStone" => true,
                        "CustomerStoneValue" => 5.0
                    ), array(
                        "Location" => 1,
                        "Number" => "sample string 2",
                        "SerialNumber" => "sample string 3",
                        "IsCustomerStone" => true,
                        "CustomerStoneValue" => 5.0
                    )
                ),
                "Engravings" => array(
                    "EngravingLine" => array(
                        "LineLocation" => 1,
                        "Text" => "sample string 2"
                    ), array(
                        "LineLocation" => 1,
                        "Text" => "sample string 2"
                    )
                ),
                "Location" => 1,
                "EngravingType" => "sample string 2",
                "FontType" => "sample string 3",
                "FontSize" => "sample string 4",
                "FillOption" => "sample string 5",
                "FillColor" => "sample string 6"
            ), array(
                "EngravingLine" => array(
                    "LineLocation" => 1,
                    "Text" => "sample string 2"
                ), array(
                    "LineLocation" => 1,
                    "Text" => "sample string 2"
                )
            ),
            "Location" => 1,
            "EngravingType" => "sample string 2",
            "FontType" => "sample string 3",
            "FontSize" => "sample string 4",
            "FillOption" => "sample string 5",
            "FillColor" => "sample string 6"

        ,
            "EarringBack" => array(
                "Number" => "sample string 1"
            ),
            "Chain" => array(
                "Number" => "sample string 1"
            ),
            "Notes" => array(
                "NoteType" => "Manufacturing",
                "Text" => "sample string 1"
            ), array(
                "NoteType" => "Manufacturing",
                "Text" => "sample string 1"
            )
        ,
            "Number" => "sample string 1",
            "RingSize" => 2.0,
            "ChainLength" => 4,
            "Instructions" => "sample string 6",
            "AdditionalDescription" => "sample string 7",
            "RequestedShipDate" => "sample string 8"
        , array(
                "Clasp" => array(
                    "Number" => "sample string 1"
                ),
                "Stones" => array(
                    "Location" => 1,
                    "Number" => "sample string 2",
                    "SerialNumber" => "sample string 3",
                    "IsCustomerStone" => true,
                    "CustomerStoneValue" => 5.0
                ), array(
                    "Location" => 1,
                    "Number" => "sample string 2",
                    "SerialNumber" => "sample string 3",
                    "IsCustomerStone" => true,
                    "CustomerStoneValue" => 5.0
                )
            ,
                "Engravings" => array(
                    "EngravingLine" => array(
                        "LineLocation" => 1,
                        "Text" => "sample string 2"
                    ), array(
                        "LineLocation" => 1,
                        "Text" => "sample string 2"
                    )
                ),
                "Location" => 1,
                "EngravingType" => "sample string 2",
                "FontType" => "sample string 3",
                "FontSize" => "sample string 4",
                "FillOption" => "sample string 5",
                "FillColor" => "sample string 6"
            , array(
                    "EngravingLine" => array(
                        "LineLocation" => 1,
                        "Text" => "sample string 2"
                    ), array(
                        "LineLocation" => 1,
                        "Text" => "sample string 2"
                    )
                ),
                "Location" => 1,
                "EngravingType" => "sample string 2",
                "FontType" => "sample string 3",
                "FontSize" => "sample string 4",
                "FillOption" => "sample string 5",
                "FillColor" => "sample string 6"
            )
        ,
            "EarringBack" => array(
                "Number" => "sample string 1"
            ),
            "Chain" => array(
                "Number" => "sample string 1"
            ),
            "Notes" => array(
                "NoteType" => "Manufacturing",
                "Text" => "sample string 1"
            ), array(
                "NoteType" => "Manufacturing",
                "Text" => "sample string 1"
            )
        ,
            "Number" => "sample string 1",
            "RingSize" => 2.0,
            "ChainLength" => 4,
            "Instructions" => "sample string 6",
            "AdditionalDescription" => "sample string 7",
            "RequestedShipDate" => "sample string 8"

        ,
            "Quantity" => 1,
            "ExtendedPrice" => 2.0,
            "Item" => "sample string 3",
            "Description" => "sample string 4",
            "BoxType" => "Black",
            "GiftWrap" => true,
            "BoxDescription" => "sample string 7",
            "Message" => "sample string 8",
            "LineNumber" => "sample string 9",
            "Source" => "sample string 10",
            "CustomerLineReference" => "sample string 11"

        ,
            "Type" => "sample string 1",
            "Version" => 2.0,
            "Token" => "sample string 3",
            "Account" => "sample string 4",
            "OrderID" => "sample string 5",
            "PurchaseOrderNumber" => "sample string 6",
            "IfOosType" => "Backorder",
            "TestMode" => true,
            "StoreNumber" => "sample string 8",
            "Instructions" => "sample string 9",
            "PackingSlipPath" => "sample string 10"
        );
        if($order->get_items()){
            foreach($order->get_items() as $item){
                $_product       = $order->get_product_from_item( $item );
                $data['Lines']['Items'][] = array(
                    "Stones" => array(
                        "Location" => 1,
                        "Number" => $item['qty'],
                        "SerialNumber" => "sample string 3",
                        "IsCustomerStone" => true,
                        "CustomerStoneValue" => 5.0
                    )
                );
            }
        }
    }
}
/*

{
    global $installedDbVersion;
    if (get_site_option('dbxstl_db_version') != DBXSTL_DB_VERSION) {
        dbxstl_install();
    }
}

add_action('plugins_loaded', 'dbxstl_update_db_check');
*/