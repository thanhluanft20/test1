<?php exit; 
/*
?>

API Documentation


forget this link:
https://www.stuller.com/myaccount/ecommercesettings/selfserviceapidocumentationunauthenticated/

Use these:

http://www.stuller.com/api/help

http://www.stuller.com/api/Help/Api/POST-v1-Orders-SubmitOrder

*/

$data = array (
  "CustomerData" => array(
    "OrderNumber" =>  "sample string 1",
    "OrderDate" =>  "2014-05-13T20:33:26.2977124-05:00",
    "EmailConfirmation" => array(
      "FromAddress" =>  "sample string 1",
      "SendOrderConfirmation" =>  true,
      "SendShipmentConfirmation" =>  true,
      "ToAddress" =>  "sample string 4"
    ),
    "ExtraAmount" => array(
      "Label" =>  "sample string 1",
      "Value" =>  "sample string 2"
    ),
    "FreightAmount" =>  3.1,
    "TaxAmount" =>  4.1,
    "Message1" =>  "sample string 5",
    "Message2" =>  "sample string 6",
    "AdditionalData" => array()
  ),
  "Contact" => array(
    "Name" =>  "sample string 1",
    "Phone" =>  "sample string 2",
    "EmailAddress" =>  "sample string 3"
  ),
  "Payment" => array(
    "CardNumber" =>  "sample string 1",
    "CardHolderName" =>  "sample string 2",
    "ExpirationDate" =>  "sample string 3",
    "Type" =>  "Terms"
  ),
  "ShipToAddress" => array(
    "Address" => array(
      "Name" =>  "sample string 1",
      "AddressLine1" =>  "sample string 2",
      "AddressLine2" =>  "sample string 3",
      "City" =>  "sample string 4",
      "State" =>  "sample string 5",
      "PostalCode" =>  "sample string 6",
      "Province" =>  "sample string 7",
      "Country" =>  "sample string 8",
      "Phone" =>  "sample string 9"
    ),
    "ShipComplete" =>  true,
    "ShipMethodType" =>  "UPS_NEXT_DAY",
    "RemovePricing" =>  true,
    "SignatureRequired" =>  true
  ),
  "BillToAddress" => array(
    "Address" => array(
      "Name" =>  "sample string 1",
      "AddressLine1" =>  "sample string 2",
      "AddressLine2" =>  "sample string 3",
      "City" =>  "sample string 4",
      "State" =>  "sample string 5",
      "PostalCode" =>  "sample string 6",
      "Province" =>  "sample string 7",
      "Country" =>  "sample string 8",
      "Phone" =>  "sample string 9"
    ),
    "SameAsShipTo" =>  true
  ),
  "Lines" =>  array(
      "Items" =>  array(
          "Clasp" => array(
            "Number" =>  "sample string 1"
          ),
          "Stones" =>  array(
              "Location" =>  1,
              "Number" =>  "sample string 2",
              "SerialNumber" =>  "sample string 3",
              "IsCustomerStone" =>  true,
              "CustomerStoneValue" =>  5.0
            ),array(
              "Location" =>  1,
              "Number" =>  "sample string 2",
              "SerialNumber" =>  "sample string 3",
              "IsCustomerStone" =>  true,
              "CustomerStoneValue" =>  5.0
            )
          ),
          "Engravings" =>  array(
              "EngravingLine" =>  array(
                  "LineLocation" =>  1,
                  "Text" =>  "sample string 2"
                ),array(
                  "LineLocation" =>  1,
                  "Text" =>  "sample string 2"
                )
              ),
              "Location" =>  1,
              "EngravingType" =>  "sample string 2",
              "FontType" =>  "sample string 3",
              "FontSize" =>  "sample string 4",
              "FillOption" =>  "sample string 5",
              "FillColor" =>  "sample string 6"
            ,
            array(
              "EngravingLine" =>  array(
                  "LineLocation" =>  1,
                  "Text" =>  "sample string 2"
                ),array(
                  "LineLocation" =>  1,
                  "Text" =>  "sample string 2"
                )
              ),
              "Location" =>  1,
              "EngravingType" =>  "sample string 2",
              "FontType" =>  "sample string 3",
              "FontSize" =>  "sample string 4",
              "FillOption" =>  "sample string 5",
              "FillColor" =>  "sample string 6"
            ,
          "EarringBack" => array(
            "Number" =>  "sample string 1"
          ),
          "Chain" => array(
            "Number" =>  "sample string 1"
          ),
          "Notes" =>  array(
              "NoteType" =>  "Manufacturing",
              "Text" =>  "sample string 1"
            ),array(
              "NoteType" =>  "Manufacturing",
              "Text" =>  "sample string 1"
            )
          ,
          "Number" =>  "sample string 1",
          "RingSize" =>  2.0,
          "ChainLength" =>  4,
          "Instructions" =>  "sample string 6",
          "AdditionalDescription" =>  "sample string 7",
          "RequestedShipDate" =>  "sample string 8"
        ,array(
          "Clasp" => array(
            "Number" =>  "sample string 1"
          ),
          "Stones" =>  array(
              "Location" =>  1,
              "Number" =>  "sample string 2",
              "SerialNumber" =>  "sample string 3",
              "IsCustomerStone" =>  true,
              "CustomerStoneValue" =>  5.0
            ),array(
              "Location" =>  1,
              "Number" =>  "sample string 2",
              "SerialNumber" =>  "sample string 3",
              "IsCustomerStone" =>  true,
              "CustomerStoneValue" =>  5.0
            )
          ),
          "Engravings" =>  array(
              "EngravingLine" =>  array(
                  "LineLocation" =>  1,
                  "Text" =>  "sample string 2"
                ),array(
                  "LineLocation" =>  1,
                  "Text" =>  "sample string 2"
                )
              ),
              "Location" =>  1,
              "EngravingType" =>  "sample string 2",
              "FontType" =>  "sample string 3",
              "FontSize" =>  "sample string 4",
              "FillOption" =>  "sample string 5",
              "FillColor" =>  "sample string 6"
            ),array(
              "EngravingLine" =>  array(
                  "LineLocation" =>  1,
                  "Text" =>  "sample string 2"
                ),array(
                  "LineLocation" =>  1,
                  "Text" =>  "sample string 2"
                )
              ,
              "Location" =>  1,
              "EngravingType" =>  "sample string 2",
              "FontType" =>  "sample string 3",
              "FontSize" =>  "sample string 4",
              "FillOption" =>  "sample string 5",
              "FillColor" =>  "sample string 6"
            )
          ,
          "EarringBack" => array(
            "Number" =>  "sample string 1"
          ),
          "Chain" => array(
            "Number" =>  "sample string 1"
          ),
          "Notes" =>  array(
              "NoteType" =>  "Manufacturing",
              "Text" =>  "sample string 1"
            ),array(
              "NoteType" =>  "Manufacturing",
              "Text" =>  "sample string 1"
            )
          ,
          "Number" =>  "sample string 1",
          "RingSize" =>  2.0,
          "ChainLength" =>  4,
          "Instructions" =>  "sample string 6",
          "AdditionalDescription" =>  "sample string 7",
          "RequestedShipDate" =>  "sample string 8"
        
      ,
      "Quantity" =>  1,
      "ExtendedPrice" =>  2.0,
      "Item" =>  "sample string 3",
      "Description" =>  "sample string 4",
      "BoxType" =>  "Black",
      "GiftWrap" =>  true,
      "BoxDescription" =>  "sample string 7",
      "Message" =>  "sample string 8",
      "LineNumber" =>  "sample string 9",
      "Source" =>  "sample string 10",
      "CustomerLineReference" =>  "sample string 11"
    ,array(
      "Items" =>  array(
          "Clasp" => array(
            "Number" =>  "sample string 1"
          ),
          "Stones" =>  array(
              "Location" =>  1,
              "Number" =>  "sample string 2",
              "SerialNumber" =>  "sample string 3",
              "IsCustomerStone" =>  true,
              "CustomerStoneValue" =>  5.0
            ),array(
              "Location" =>  1,
              "Number" =>  "sample string 2",
              "SerialNumber" =>  "sample string 3",
              "IsCustomerStone" =>  true,
              "CustomerStoneValue" =>  5.0
            )
          ),
          "Engravings" =>  array(
              "EngravingLine" =>  array(
                  "LineLocation" =>  1,
                  "Text" =>  "sample string 2"
                ),array(
                  "LineLocation" =>  1,
                  "Text" =>  "sample string 2"
                )
              ),
              "Location" =>  1,
              "EngravingType" =>  "sample string 2",
              "FontType" =>  "sample string 3",
              "FontSize" =>  "sample string 4",
              "FillOption" =>  "sample string 5",
              "FillColor" =>  "sample string 6"
            ),array(
              "EngravingLine" =>  array(
                  "LineLocation" =>  1,
                  "Text" =>  "sample string 2"
                ),array(
                  "LineLocation" =>  1,
                  "Text" =>  "sample string 2"
                )
              ),
              "Location" =>  1,
              "EngravingType" =>  "sample string 2",
              "FontType" =>  "sample string 3",
              "FontSize" =>  "sample string 4",
              "FillOption" =>  "sample string 5",
              "FillColor" =>  "sample string 6"
            
          ,
          "EarringBack" => array(
            "Number" =>  "sample string 1"
          ),
          "Chain" => array(
            "Number" =>  "sample string 1"
          ),
          "Notes" =>  array(
              "NoteType" =>  "Manufacturing",
              "Text" =>  "sample string 1"
            ),array(
              "NoteType" =>  "Manufacturing",
              "Text" =>  "sample string 1"
            )
          ,
          "Number" =>  "sample string 1",
          "RingSize" =>  2.0,
          "ChainLength" =>  4,
          "Instructions" =>  "sample string 6",
          "AdditionalDescription" =>  "sample string 7",
          "RequestedShipDate" =>  "sample string 8"
        ,array(
          "Clasp" => array(
            "Number" =>  "sample string 1"
          ),
          "Stones" =>  array(
              "Location" =>  1,
              "Number" =>  "sample string 2",
              "SerialNumber" =>  "sample string 3",
              "IsCustomerStone" =>  true,
              "CustomerStoneValue" =>  5.0
            ),array(
              "Location" =>  1,
              "Number" =>  "sample string 2",
              "SerialNumber" =>  "sample string 3",
              "IsCustomerStone" =>  true,
              "CustomerStoneValue" =>  5.0
            )
          ,
          "Engravings" =>  array(
              "EngravingLine" =>  array(
                  "LineLocation" =>  1,
                  "Text" =>  "sample string 2"
                ),array(
                  "LineLocation" =>  1,
                  "Text" =>  "sample string 2"
                )
              ),
              "Location" =>  1,
              "EngravingType" =>  "sample string 2",
              "FontType" =>  "sample string 3",
              "FontSize" =>  "sample string 4",
              "FillOption" =>  "sample string 5",
              "FillColor" =>  "sample string 6"
            ,array(
              "EngravingLine" =>  array(
                  "LineLocation" =>  1,
                  "Text" =>  "sample string 2"
                ),array(
                  "LineLocation" =>  1,
                  "Text" =>  "sample string 2"
                )
              ),
              "Location" =>  1,
              "EngravingType" =>  "sample string 2",
              "FontType" =>  "sample string 3",
              "FontSize" =>  "sample string 4",
              "FillOption" =>  "sample string 5",
              "FillColor" =>  "sample string 6"
            )
          ,
          "EarringBack" => array(
            "Number" =>  "sample string 1"
          ),
          "Chain" => array(
            "Number" =>  "sample string 1"
          ),
          "Notes" =>  array(
              "NoteType" =>  "Manufacturing",
              "Text" =>  "sample string 1"
            ),array(
              "NoteType" =>  "Manufacturing",
              "Text" =>  "sample string 1"
            )
          ,
          "Number" =>  "sample string 1",
          "RingSize" =>  2.0,
          "ChainLength" =>  4,
          "Instructions" =>  "sample string 6",
          "AdditionalDescription" =>  "sample string 7",
          "RequestedShipDate" =>  "sample string 8"
        
      ,
      "Quantity" =>  1,
      "ExtendedPrice" =>  2.0,
      "Item" =>  "sample string 3",
      "Description" =>  "sample string 4",
      "BoxType" =>  "Black",
      "GiftWrap" =>  true,
      "BoxDescription" =>  "sample string 7",
      "Message" =>  "sample string 8",
      "LineNumber" =>  "sample string 9",
      "Source" =>  "sample string 10",
      "CustomerLineReference" =>  "sample string 11"
    
  ,
  "Type" =>  "sample string 1",
  "Version" =>  2.0,
  "Token" =>  "sample string 3",
  "Account" =>  "sample string 4",
  "OrderID" =>  "sample string 5",
  "PurchaseOrderNumber" =>  "sample string 6",
  "IfOosType" =>  "Backorder",
  "TestMode" =>  true,
  "StoreNumber" =>  "sample string 8",
  "Instructions" =>  "sample string 9",
  "PackingSlipPath" =>  "sample string 10"
);

print_r($data);