<?php
/**
 * Plugin Name: Test Wp Ajax
 * Plugin URI: http://URI_Of_Page_Describing_Plugin_and_Updates
 * Description: Test Build
 * Version:  1.0
 */

class order_Processor
{
	public function __construct()
	{
		if (is_admin())
		{
			add_action('wp_ajax_nopriv_process-order', array(&$this, 'process_Order'));
			add_action('wp_ajax_process-order', array(&$this, 'process_Order'));
		}
		add_action('wp', array(&$this, 'init'));
	}

	public function init()
	{
		if (!is_admin())
		{
			global $post;

			$product_data = $this->get_Product_Data($post);
			$order_data = $this->get_Order_Data($post);

			wp_register_script('order-processor', plugin_dir_url(__FILE__) . 'processor-obj.js');
			//wp_register_script('ui-handler', plugin_dir_url(__FILE__) . 'ui-handler.js');
			wp_enqueue_script('app-runtime', plugin_dir_url(__FILE__) . 'app-run.js', array('jquery','jquery-ui-slider', 'underscore', 'order-processor'));

			wp_localize_script('app-runtime', 'ajax_data', array('ajaxurl'		=> admin_url('admin-ajax.php'),
				 'nonce'		=> wp_create_nonce('process-order-nonce'),
				 'product_data' => $product_data,
				 'order_data'	=> $order_data));
		}
	}

	public function get_Order_Data($post)
	{
		$order_data['order_ID'] = "order1234";
		return $order_data;
	}

	public function get_Product_Data($post)
	{

		$product_data = array(
			"prod_min" => 3,
	    "prod_sku" => "sku you too",
	    "prod_max" => 300,
	    "prod_divs" => 3,
		);
		
		return $product_data;
	}

	public function process_Order()
	{
		if (!isset($_REQUEST['nonce']) || !wp_verify_nonce($_REQUEST['nonce'], 'process-order-nonce'))
			die('Invalid Nonce');
		else
		{
			$ORDERDATA = $_REQUEST['order_data'];
			$PRODINFO = $ORDERDATA['product_data'];
			$ORDERINFO = $ORDERDATA['order_data'];

			header("Content-Type: application/json");
			echo json_encode(array('success' => true,
								   'order_content' => $PRODINFO));
			exit;
		}
		//end else
	}
}
$CORE = new order_Processor();

?>