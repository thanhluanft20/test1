function order_Processor(ajaxdata)
{
	this.ajaxdata	 = ajaxdata;
	this.order_data	= {};
	this.order_data['product_data']	 = {};
	this.order_data['order_data']	= {};
	this.order_data['product_data']['product_divisions'] = {};
	this.proddiv	 = this.order_data['product_data']['product_divisions'];

	this.set_Order_Data = function(data)
	{
		
		_.extend(this.order_data['product_data'], this.ajaxdata['product_data']);
		_.extend(this.order_data['order_data'], this.ajaxdata['order_data']);
		this.maxdivsions = this.order_data['product_data']['prod_divs'];
		//console.info('This came from php.');
		//console.log(this.order_data);
	};

	this.add_Product_Props = function(name,prop)
	{
			this.order_data['product_data'][name] = prop;
	};

	this.remove_Product_Props = function(name)
	{
		delete this.order_data['product_data'][name];
	};

	this.add_Product_Division = function(divsionname)
	{
		if(_.size(this.proddiv) < this.maxdivsions){ this.proddiv[divsionname] = {}; console.log("aaded div");}
		else {console.warn("Divsion add failed: reached max divsions"); return true; }
	};

	this.remove_Product_Division = function(divsionname)
	{
		if(_.has(this.proddiv, divsionname))
			this.proddiv = _.omit(this.proddiv, divsionname);
		else
		{
			console.error('remove prod div failed: no vaild divsion');
			return false;
		}
	};

	this.add_Product_Division_Props = function(divsionname, props)
	{
		if(_.has(this.proddiv, divsionname))
			_.extend(this.proddiv[divsionname], props);
		else
		{
			console.error('add prop to prod div failed: no parent divsion');
			return false;
		}
	};

	this.remove_Product_Division_Props = function(divsionname, props)
	{
		if(_.has(this.proddiv, divsionname))
		{
			if(_.has(this.proddiv[divsionname], props))
				this.proddiv[divsionname] = _.omit(this.proddiv[divsionname], props);
			else
			{
				console.error('remove prop to prod div failed: no vaild divsion prop found');
				return false;
			}
		}

		else
		{
			console.error('remove prop to prod div failed: no parent divsion');
			return false;
		}
	};

	this.add_Sub_Product_Division_Props = function(parent_divsionname, divsionname, props)
	{
		if(_.has(this.proddiv, parent_divsionname))
		{
			if(!_.has(this.proddiv[parent_divsionname], divsionname))
				this.proddiv[parent_divsionname][divsionname] = {};
			_.extend(this.proddiv[parent_divsionname][divsionname], props);
		}

		else
		{
			console.error('add sub div to prod div failed: no parent divsion');
			return false;
		}
	};

	this.remove_Sub_Product_Division_Props = function(parent_divsionname, divsionname, props)
	{
		if(_.has(this.proddiv, parent_divsionname))
		{
			if(!_.has(this.proddiv[parent_divsionname], divsionname))
				this.proddiv[parent_divsionname][divsionname] = {};
			_.omit(this.proddiv[parent_divsionname][divsionname], props);
		}

		else
		{
			console.error('add sub div to prod div failed: no parent divsion');
			return false;
		}
	};

	this.getCount = function(dataobject)
	{
		var total = _.reduce(_.values(dataobject), function(memo, num){ return memo + num;}, 0);
		return total;
	};

	this.process_Order = function()
	{
		jQuery.getJSON(this.ajaxdata.ajaxurl, { action: 'process-order',
			nonce: this.ajaxdata.nonce,
			order_data: this.order_data }, function(response)
		   {
			   console.info('This came from js to php and back.');
			   console.log(response);
		   });
	};
}//END OF OBJ