var ORDER = new order_Processor(ajax_data);
var UI = new order_UIhandler(ORDER);
ORDER.set_Order_Data();
ORDER.add_Product_Division('red');
ORDER.add_Product_Division_Props('red', { threadcolor: 'red', imprint: 'sleave' });
ORDER.add_Sub_Product_Division_Props('red', 'sizes', { med: 10, small: 23 });
UI.thisTest();
//UI.BindColors($jQ('.addon-color-swatch'),, this.size != null);
ORDER.process_Order();


function order_UIhandler(processer){
	this.curframeset = 0;
	var OD = processer;
	var $jQ = jQuery;
	var proddata = OD['order_data']['product_data'];
	this.thisTest = function(){

		$jQ(document).ready(function() {
				applycolor();
				applyimprint();
				applyquanity();
		});
		
	}


	function applyquanity(){
		$jQ( "#quanty-slider").slider({
      slide: function( event, ui ) {
        OD.add_Product_Props('quantity', ui.value);
        $jQ("#quant").val(ui.value)
        console.log("quant: "+ ui.value);
      }
    })


	$jQ("#quant").focus(function() {
  	$jQ(this).on("change",function(event) { 
    	var val = $jQ(this).val();
    	if(val < proddata.prod_min){val = proddata.prod_min}
    	if(val > proddata.prod_max){val = proddata.prod_max}
    	$jQ( "#quanty-slider").slider( "value", val); 
    });
	});
    
	}




	function applycolor(){
		
			$jQ('.addon-color-swatch').each(function(index, el) {
			  $jQ(this).click(function(event){
			  			var el = $jQ(this); 
					   	var name = el.parents('.input-parent').data('name');
					   switch(name) {
							    case "product-colors":
							         addcolor(el);
							        break;
							    case "threadcolor":
							         addthreadcolor(el)
							        break;
							    default:
							        console.error("color selection fail");
						}
		 		 	});
			});

	}
	
	function applyimprint(){
		
			$jQ('.addon-imprint-location').each(function(index, el) {
			  $jQ(this).click(function(event){ 
			  			var el = $jQ(this); 
			  			var name = el.parents('.input-parent').data('name');
			  			console.log("addprop name"+ name);
					   	addOrderProp(el, name);

		 		 	});
			});

	}

	function addcolor(el){
			var value = el.data('value');
 		 if(!el.hasClass('clicked')){
 		 		OD.add_Product_Division(value);
  			el.addClass('clicked');
 		 }
 		 else{
	 		 	OD.remove_Product_Division(value);
	  		el.removeClass('clicked');
 		 }
	}

	function addthreadcolor(el){
			var value = el.data('value');
			var parent = el.parents('.input-parent').data('parent');
 		 if(!el.hasClass('clicked')){
 		 		OD.add_Sub_Product_Division_Props(parent, "thread-color", value);
  			el.addClass('clicked');
 		 }
 		 else{
	 		 	OD.remove_Sub_Product_Division_Props(parent, "thread-color", value);
	  		el.removeClass('clicked');
 		 }
	}


		function addOrderProp(el, name){
		 var value = el.data('value');
 		 if(!el.hasClass('clicked')){
 		 		OD.add_Product_Props(name,value);
 		 		console.log("'added:"+OD['product_data'][name]);
  			el.addClass('clicked');
 		 }
 		 else{
	 		 	OD.remove_Product_Props(name);
	 		 	console.log("removed:"+OD['product_data'][name]);
	  		el.removeClass('clicked');
 		 }
	}

}//end sca