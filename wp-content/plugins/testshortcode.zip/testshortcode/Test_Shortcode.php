<?php
/*
Plugin Name: IZWEB Test Shortcode
Plugin URI: http://izweb.biz
Description: asdasdbma bsmdas dasd
Version: 1.0.0
Author: Ho Hien
Author URI: http://izweb.biz
*/

class Test_Shortcode {
    function __construct(){
        add_shortcode( 'showtext', array( __CLASS__, 'showtext' ) );
        add_filter('test_shortcode',array( $this, 'custom_filter_test_shortcode' ) , 10,3 );
        //add_action('test_shortcode',array( $this, 'custom_action_test_shortcode' ) , 10,3 );
    }
    function showtext( $atts, $content = null ) {
        $a = shortcode_atts( array(
            'title' => 'Text default',
            'class' => 'title',
            'id' => 'test',
            'container' => '<div id="%s" class="%s">%s</div>',
        ), $atts );
        $text = sprintf($a['container'],$a['id'],$a['class'],$a['title']);
        do_action('test_shortcode',$text,$atts,$content);
        //return $text;
        return apply_filters('test_shortcode',$text,$atts,$content);
    }
    function custom_filter_test_shortcode($text,$atts,$content){
        $a = shortcode_atts( array(
            'title' => 'Text default',
            'class' => 'title',
            'id' => 'test',
            'container' => '<div id="%s" class="%s"><h2>%s</h2></div>',
        ), $atts );
        $text = sprintf($a['container'],$a['id'],$a['class'],$a['title']);
        return $text;
    }
    function custom_action_test_shortcode($text,$atts,$content){
        $a = shortcode_atts( array(
            'title' => 'Text default',
            'class' => 'title',
            'id' => 'test',
            'container' => '<div id="%s" class="%s">%s</div>',
        ), $atts );
        $text = sprintf($a['container'],$a['id'],$a['class'],$a['title']);
        return apply_filters('test_shortcode',$text,$atts,$content);
    }
}
new Test_Shortcode();