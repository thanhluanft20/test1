<?php
/*
Plugin Name: IZWEB Custom Email
Plugin URI: http://izweb.biz
Description: Registration emails custom.
Version: 1.0.0
Author: Sy Le
Author URI: http://izweb.biz
*/
function birthday($birthday) {
	//$birthday = date("Y-m-d", strtotime($birthday));
	$age = date_create($birthday)->diff(date_create('today'))->y;
	return $age;
}

add_filter( 'wp_mail_content_type', 'rw_change_email_content_type', 100 );
function rw_change_email_content_type( $content_type )
{
    return 'text/html';
}
add_filter( 'phpmailer_init', 'rw_change_phpmailer_object' );
function rw_change_phpmailer_object( $phpmailer )
{
	$phpmailer->IsHTML( true );
}

add_action( 'admin_menu',  'my_admin_menu' ,1);
add_action( 'admin_footer', 'izweb_export_csv');
remove_action( 'tml_new_user_registered',   'wp_new_user_notification', 10, 2 );
function my_admin_menu(){
    //add_submenu_page( 'tools.php' , 'Export CSV' , 'Export CSV' , 'manage_options' , 'izweb_export_csv','izweb_export_csv');
	add_meta_box( 'babysitter_activation', __( 'Babysitter Activation', 'theme-my-login' ), 'babysitter_activation_meta_box' ,'tml_page_theme_my_login_email', 'normal' );
	add_meta_box( 'new_babysitter', __( 'New Babysitter', 'theme-my-login' ), 'new_babysitter_meta_box' ,'tml_page_theme_my_login_email', 'normal' );
	add_meta_box( 'new_babysitter_to_parent', __( 'Inform to parent when new babysitter registed', 'theme-my-login' ), 'new_babysitter_to_parent_meta_box' ,'tml_page_theme_my_login_email', 'normal' );
	add_meta_box( 'one_month_send', __( 'Monthly Send To babysitter', 'theme-my-login' ), 'one_month_meta_box' ,'tml_page_theme_my_login_email', 'normal' );
	add_meta_box( 'six_hours_send', __( 'Report to admin after 6 hours', 'theme-my-login' ), 'six_hours_meta_box' ,'tml_page_theme_my_login_email', 'normal' );
	add_meta_box( 'daily_send', __( 'Resend activation', 'theme-my-login' ), 'daily_meta_box' ,'tml_page_theme_my_login_email', 'normal' );
}
add_filter( 'new_user_notification_title',  'my_new_user_notification_title_filter', 11, 2 );
function my_new_user_notification_title_filter($title, $user_id){
	$user = new WP_User( $user_id );
	$role = reset($user->roles);
	if ($role == 'subscriber') {
		$options = get_option('theme_my_login_email');
		return Theme_My_Login_Common::replace_vars( $options['new_babysitter']['title'], $user_id );
	}

	return $title;
}
function replace_form_fields($user_id) {
	$user = new WP_User( $user_id );
	$role = reset($user->roles);
	$form_fields = '<table>';
	if ($role == 'subscriber') {
		$job_id = get_user_meta($user_id, '_job_id', true);
		$options = get_option('theme_my_login_email');
		$rate = get_post_meta($job_id,"_company_rate", true);
		$gender = get_post_meta($job_id,"_company_gender", true);
		$dob = get_post_meta($job_id,"_company_age", true);
		$job_location = get_post_meta($job_id,"_job_location", true);
		$info_fat = get_post_meta($job_id,"_company_info_fat", true);
		$application = get_post_meta($job_id,"_application", true);
		$info_course = get_post_meta($job_id,"_company_info_course", true);
		$info_cpr = get_post_meta($job_id,"_company_info_cpr", true);
		$job_live = get_post_meta($job_id,"_job_live", true);
		$job_description = get_post_meta($job_id,"_job_description", true);
		$age = birthday($dob);
		$terms = get_the_term_list( $job_id, 'job_listing_category', '', ', ', '' );
		$terms = strip_tags( $terms );
		$form_fields .= '<tr><td style="width:20%;"><b>First Name</b></td><td style="width:80%;">'.$user->first_name.'</td></tr>';
		$form_fields .= '<tr><td style="width:20%;"><b>Last Name</b></td><td style="width:80%;">'.$user->last_name.'</td></tr>';
		$form_fields .= '<tr><td style="width:20%;"><b>Lives in</b></td><td style="width:80%;">'.$job_live.'</td></tr>';
		$form_fields .= '<tr><td style="width:20%;"><b>Gender</b></td><td style="width:80%;">'.$gender.'</td></tr>';
		$form_fields .= '<tr><td style="width:20%;"><b>Rate</b></td><td style="width:80%;">'.$rate.'</td></tr>';
		$form_fields .= '<tr><td style="width:20%;"><b>Age</b></td><td style="width:80%;">'.$age.'</td></tr>';
		$form_fields .= '<tr><td style="width:20%;"><b>Postal Code</b></td><td style="width:80%;">'.$job_location.'</td></tr>';
		$form_fields .= '<tr><td style="width:20%;"><b>Phone Number</b></td><td style="width:80%;">'.$application.'</td></tr>';
		$form_fields .= '<tr><td style="width:20%;"><b>Babysitter Course</b></td><td style="width:80%;">'.$info_course.'</td></tr>';
		$form_fields .= '<tr><td style="width:20%;"><b>First Aid Training</b></td><td style="width:80%;">'.$info_fat.'</td></tr>';
		$form_fields .= '<tr><td style="width:20%;"><b>CPR Certified</b></td><td style="width:80%;">'.$info_cpr.'</td></tr>';
		$form_fields .= '<tr><td colspan="2" style="width:100%"><p><b>Communities</b><br>'.$terms.'</p></td></tr>';
		$form_fields .= '<tr><td colspan="2" style="width:100%"><p><b>Description</b><br>'.$job_description.'</p></td></tr>';
	} else {
		$first_name = get_user_meta( $user_id, 'first_name', true );
		$last_name	= get_user_meta( $user_id, 'last_name', true );
		$phone		= get_user_meta( $user_id, 'phone', true );
		$community	= get_user_meta( $user_id, 'community', true );
		$term 		= get_term_by('slug', $community, 'job_listing_category');
		$community 	= $term->name;
		$form_fields .= '<tr><td style="width:20%;"><b>First Name</b></td><td style="width:80%;">'.$first_name.'</td></tr>';
		$form_fields .= '<tr><td style="width:20%;"><b>Last Name</b></td><td style="width:80%;">'.$last_name.'</td></tr>';
		$form_fields .= '<tr><td style="width:20%;"><b>Phone</b></td><td style="width:80%;">'.$phone.'</td></tr>';
		$form_fields .= '<tr><td style="width:20%;"><b>Community</b></td><td style="width:80%;">'.$community.'</td></tr>';
	}
	$form_fields .= '</table>';
	return $form_fields;
}

add_filter( 'new_user_admin_notification_message', 'my_new_user_admin_notification_message_filter', 11, 2 );
function my_new_user_admin_notification_message_filter($message, $user_id){
	$message = str_replace('[form_fields]',replace_form_fields($user_id), $message);
	return $message;
}
add_filter( 'user_activation_notification_title',  'babysitter_activation_notification_title'   , 999, 2 );
function babysitter_activation_notification_title($title, $user_id){
    $babysitter = get_user_meta($user_id,'babysitter',true);
    $options = get_option('theme_my_login_email');
    if(!empty($options['babysitter_activation']['message']) && !empty($babysitter) && $babysitter == 'yes'){
        $_title = $options['babysitter_activation']['title'];
    }
    return empty( $_title ) ? $title : Theme_My_Login_Common::replace_vars( $_title, $user_id );
}
add_filter( 'user_activation_notification_message', 'babysitter_activation_notification_message' , 999, 3 );
function babysitter_activation_notification_message($message, $activation_url, $user_id){
    $babysitter = get_user_meta($user_id,'babysitter',true);
    $options = get_option('theme_my_login_email');
    if(!empty($options['babysitter_activation']['message']) && !empty($babysitter) && $babysitter == 'yes'){
        $message_IZ = $options['babysitter_activation']['message'];
        $userData = get_userdata($user_id);
        $message = Theme_My_Login_Common::replace_vars( $message_IZ, $user_id, array(
            '%first_name%' => $userData->first_name,
            '%activateurl%' => $activation_url,
            '%blogname%' => get_bloginfo( 'name' ),
            '%siteurl%' => get_bloginfo( 'url' ),
            '%user_login%' => $userData->user_login,
            '%user_email%' => $userData->user_email
        ) );
    }
    return $message;
}

add_filter( 'new_user_notification_message', 'my_new_user_notification_message_filter', 11, 3 );
function my_new_user_notification_message_filter($message, $new_pass, $user_id){
	$user = new WP_User( $user_id );
	$role = reset($user->roles);
	$options = get_option('theme_my_login_email');
	if ($role == 'subscriber' && !empty( $options['new_babysitter']['message'])) {
        $message_IZ = $options['new_babysitter']['message'];
		$message = Theme_My_Login_Common::replace_vars( $message_IZ, $user_id, array(
				'%loginurl%'  	=> site_url( 'wp-login.php', 'login' ),
				'%user_pass%' 	=> $new_pass,
				'%user_name%' 	=> $user->first_name,
				'parents' 	=> "babysitter"
			) );
	}
	$message = str_replace('[form_fields]',replace_form_fields($user_id), $message);
	return $message;
}

if (!function_exists('wp_new_user_notification')) {
	function wp_new_user_notification($user_id, $plaintext_pass = '', $reminder = false) {
        $user = new WP_User( $user_id );
        $role = reset($user->roles);
        if($role == 'subscriber'){
            update_user_meta($user_id,'babysitter','yes');
            update_user_meta($user_id,'activation','no');
            update_user_meta( $user_id, 'user_pass', $plaintext_pass );
        }
        return false;
	}
}
add_action("admin_init", "submit_csv");
function submit_csv(){
    if(isset($_POST['submit_csv'])){
        $taxonomies = array(
            'job_listing_category'
        );
        $args = array(
            'hide_empty'    => true,
        );
        $allterm = get_terms($taxonomies,$args);
        $write = array();
        if(sizeof($allterm)>0){
            foreach($allterm as $term){
                $write[] = array(
                    $term->name,
                );
                $write[] = array(
                    'Name',
                    'Age',
                    'Phone',
                    'Lives in'
                );
                $query = new WP_Query(array(
                        'post_type' => 'job_listing',
                        'posts_per_page' => -1,
                        'post_status' => 'publish',
                        'tax_query' => array(
                            array(
                                'taxonomy' => 'job_listing_category',
                                'field' => 'slug',
                                'terms' => $term->slug
                            )
                        )
                    )
                );
                if($query->have_posts()){
                    while($query->have_posts()){
                        $query->the_post();
                        global $post;
                        $Name = get_the_author_meta('first_name') ? get_the_author_meta('first_name') : get_the_author_meta('last_name');
                        $Age = get_post_meta(get_the_ID(),'_company_age',true);
                        $Phone = get_post_meta(get_the_ID(),'_application',true);
                        $Live_in = get_post_meta(get_the_ID(),'_job_live',true);
                        $Age = !(empty($Age)) ? date("Y")-date("Y",strtotime($Age)) : '';
                        $write[] = array(
                            $Name,
                            $Age,
                            $Phone,
                            $Live_in
                        );
                    }
                }
                $write[] = array(
                    '',
                    '',
                    '',
                    ''
                );
                $write[] = array(
                    '',
                    '',
                    '',
                    ''
                );
            }
            download_send_headers("data_export_" . date("Y-m-d") . ".csv");
            echo array2csv($write);
            die();
        }
    }
}
function izweb_export_csv(){
    ?>
    <form name="exportcsv" id="exportcsvform" method="post" action="">
        <input type="hidden" name="submit_csv" value="ok" />
    </form>
    <script type="text/javascript">
        jQuery(document).ready(function ($){
            $("#export_csv_button").click(function (){
                $("#exportcsvform").submit();
                return false;
            });
        });
    </script>
    <?php
}
function babysitter_activation_meta_box(){
    $options = get_option('theme_my_login_email');
    //Theme_My_Login_Custom_Email::get_object()->new_user_notification(62, '11221211');
    ?>
    <p class="description">
        <?php _e( ' This e-mail will be sent to a new babysitter upon registration when "E-mail Confirmation" is checked for "User Moderation". ', 'theme-my-login' ); ?>
        <?php _e( ' Please be sure to include the variable %activateurl% or else the user will not be able to activate their account! ', 'theme-my-login' ); ?>
        <?php _e( ' If any field is left empty, the default will be used instead. ', 'theme-my-login' ); ?>
    </p>
    <table class="form-table">
        <tr valign="top">
            <th scope="row"><label for="babysitter_activation_mail_from_name"><?php _e( 'From Name', 'theme-my-login' ); ?></label></th>
            <td><input name="theme_my_login_email[babysitter_activation][mail_from_name]" type="text" id="babysitter_activation_mail_from_name" value="<?php echo @$options['babysitter_activation']['mail_from_name'];?>" class="regular-text" /></td>
        </tr>
        <tr valign="top">
            <th scope="row"><label for="babysitter_activation_mail_from"><?php _e( 'From E-mail', 'theme_my_login_email' ); ?></label></th>
            <td><input name="theme_my_login_email[babysitter_activation][mail_from]" type="text" id="babysitter_activation_mail_from" value="<?php echo @$options['babysitter_activation']['mail_from']; ?>" class="regular-text" /></td>
        </tr>
        <tr valign="top">
            <th scope="row"><label for="babysitter_activation_mail_content_type"><?php _e( 'E-mail Format', 'theme_my_login_email' ); ?></label></th>
            <td>
                <select name="theme_my_login_email[babysitter_activation][mail_content_type]" id="babysitter_activation_mail_content_type">
                    <option value="plain"<?php selected( @$options['babysitter_activation']['mail_content_type'], 'plain' ); ?>><?php _e( 'Plain Text', 'theme_my_login_email' ); ?></option>
                    <option value="html"<?php  selected( @$options['babysitter_activation']['mail_content_type'], 'html' ); ?>><?php  _e( 'HTML', 'theme_my_login_email' ); ?></option>
                </select>
            </td>
        </tr>
        <tr valign="top">
            <th scope="row"><label for="babysitter_activation_title"><?php _e( 'Subject', 'theme_my_login_email' ); ?></label></th>
            <td><input name="theme_my_login_email[babysitter_activation][title]" type="text" id="babysitter_activation_title" value="<?php echo @$options['babysitter_activation']['title']; ?>" class="large-text" /></td>
        </tr>
        <tr valign="top">
            <th scope="row"><label for="babysitter_activation_message"><?php _e( 'Message', 'theme_my_login_email' ); ?></label></th>
            <td>
                <p class="description"><?php _e( 'Available Variables', 'theme_my_login_email' ); ?>: %blogname%, %siteurl%, %activateurl%, %user_login%, %user_email%</p>
                <textarea name="theme_my_login_email[babysitter_activation][message]" id="babysitter_activation_message" class="large-text" rows="10"><?php echo @$options['babysitter_activation']['message']; ?></textarea></p>
            </td>
        </tr>
    </table>
<?php
}

function new_babysitter_meta_box(){
    $options = get_option('theme_my_login_email');
    //Theme_My_Login_Custom_Email::get_object()->new_user_notification(62, '11221211');
    ?>
    <p class="description">
        <?php _e( 'This e-mail will be sent to a new user upon registration.', 'theme-my-login' ); ?>
        <?php _e( 'Please be sure to include the variable %user_pass% if using default passwords or else the user will not know their password!', 'theme-my-login' ); ?>
        <?php _e( 'If any field is left empty, the default will be used instead.', 'theme-my-login' ); ?>
    </p>
    <table class="form-table">
        <tr valign="top">
            <th scope="row"><label for="new_user_mail_from_name"><?php _e( 'From Name', 'theme-my-login' ); ?></label></th>
            <td><input name="theme_my_login_email[new_babysitter][mail_from_name]" type="text" id="new_user_mail_from_name" value="<?php echo @$options['new_babysitter']['mail_from_name'];?>" class="regular-text" /></td>
        </tr>
        <tr valign="top">
            <th scope="row"><label for="new_user_mail_from"><?php _e( 'From E-mail', 'theme_my_login_email' ); ?></label></th>
            <td><input name="theme_my_login_email[new_babysitter][mail_from]" type="text" id="new_user_mail_from" value="<?php echo @$options['new_babysitter']['mail_from']; ?>" class="regular-text" /></td>
        </tr>
        <tr valign="top">
            <th scope="row"><label for="new_user_mail_content_type"><?php _e( 'E-mail Format', 'theme_my_login_email' ); ?></label></th>
            <td>
                <select name="theme_my_login_email[new_babysitter][mail_content_type]" id="new_user_mail_content_type">
                    <option value="plain"<?php selected( @$options['new_babysitter']['mail_content_type'], 'plain' ); ?>><?php _e( 'Plain Text', 'theme_my_login_email' ); ?></option>
                    <option value="html"<?php  selected( @$options['new_babysitter']['mail_content_type'], 'html' ); ?>><?php  _e( 'HTML', 'theme_my_login_email' ); ?></option>
                </select>
            </td>
        </tr>
        <tr valign="top">
            <th scope="row"><label for="new_user_title"><?php _e( 'Subject', 'theme_my_login_email' ); ?></label></th>
            <td><input name="theme_my_login_email[new_babysitter][title]" type="text" id="new_user_title" value="<?php echo @$options['new_babysitter']['title']; ?>" class="large-text" /></td>
        </tr>
        <tr valign="top">
            <th scope="row"><label for="new_user_message"><?php _e( 'Message', 'theme_my_login_email' ); ?></label></th>
            <td>
                <p class="description"><?php _e( 'Available Variables', 'theme_my_login_email' ); ?>: %blogname%, %siteurl%, %user_login%, %user_email%, %user_pass%, %user_ip%, %user_name%, [form_fields], %unsubscribe%</p>
                <textarea name="theme_my_login_email[new_babysitter][message]" id="new_user_message" class="large-text" rows="10"><?php echo @$options['new_babysitter']['message']; ?></textarea></p>
            </td>
        </tr>
    </table>
<?php
}
function new_babysitter_to_parent_meta_box(){
	$options = get_option('theme_my_login_email');
	//Theme_My_Login_Custom_Email::get_object()->new_user_notification(62, '11221211');
	?>
		<p class="description">
			<?php _e( 'This e-mail will be sent to parents when new babysitter register.', 'theme-my-login' ); ?>
		</p>
		<table class="form-table">
			<tr valign="top">
				<th scope="row"><label for="new_babysitter_to_parent_mail_from_name"><?php _e( 'From Name', 'theme-my-login' ); ?></label></th>
				<td><input name="theme_my_login_email[new_babysitter_to_parent][mail_from_name]" type="text" id="new_babysitter_to_parent_mail_from_name" value="<?php echo @$options['new_babysitter_to_parent']['mail_from_name'];?>" class="regular-text" /></td>
			</tr>
			<tr valign="top">
				<th scope="row"><label for="new_user_mail_from"><?php _e( 'From E-mail', 'theme_my_login_email' ); ?></label></th>
				<td><input name="theme_my_login_email[new_babysitter_to_parent][mail_from]" type="text" id="new_babysitter_to_parent_mail_from" value="<?php echo @$options['new_babysitter_to_parent']['mail_from']; ?>" class="regular-text" /></td>
			</tr>
			<tr valign="top">
				<th scope="row"><label for="new_babysitter_to_parent_content_type"><?php _e( 'E-mail Format', 'theme_my_login_email' ); ?></label></th>
				<td>
					<select name="theme_my_login_email[new_babysitter][mail_content_type]" id="new_babysitter_to_parent_content_type">
						<option value="plain"<?php selected( @$options['new_babysitter_to_parent']['mail_content_type'], 'plain' ); ?>><?php _e( 'Plain Text', 'theme_my_login_email' ); ?></option>
						<option value="html"<?php  selected( @$options['new_babysitter_to_parent']['mail_content_type'], 'html' ); ?>><?php  _e( 'HTML', 'theme_my_login_email' ); ?></option>
					</select>
				</td>
			</tr>
			<tr valign="top">
				<th scope="row"><label for="new_babysitter_to_parent_title"><?php _e( 'Subject', 'theme_my_login_email' ); ?></label></th>
				<td><input name="theme_my_login_email[new_babysitter_to_parent][title]" type="text" id="new_babysitter_to_parent_title" value="<?php echo @$options['new_babysitter_to_parent']['title']; ?>" class="large-text" /></td>
			</tr>
			<tr valign="top">
				<th scope="row"><label for="new_babysitter_to_parent_message"><?php _e( 'Message', 'theme_my_login_email' ); ?></label></th>
				<td>
					<p class="description"><?php _e( 'Available Variables', 'theme_my_login_email' ); ?>: %first_name%, %post_category-job_listing_category%, [post_permalink]</p>
					<textarea name="theme_my_login_email[new_babysitter_to_parent][message]" id="new_babysitter_to_parent_message" class="large-text" rows="10"><?php echo @$options['new_babysitter_to_parent']['message']; ?></textarea></p>
				</td>
			</tr>
		</table>
		<?php
}

function one_month_meta_box(){
    $options = get_option('theme_my_login_email');
    //Theme_My_Login_Custom_Email::get_object()->new_user_notification(62, '11221211');
    ?>
    <p class="description">
        <?php _e( 'This e-mail will be sent to babysitters a month once', 'theme-my-login' ); ?>
    </p>
    <table class="form-table">
        <tr valign="top">
            <th scope="row"><label for="one_month_mail_from_name"><?php _e( 'From Name', 'theme-my-login' ); ?></label></th>
            <td><input name="theme_my_login_email[one_month][mail_from_name]" type="text" id="one_month_mail_from_name" value="<?php echo @$options['one_month']['mail_from_name'];?>" class="regular-text" /></td>
        </tr>
        <tr valign="top">
            <th scope="row"><label for="one_month_mail_from"><?php _e( 'From E-mail', 'theme_my_login_email' ); ?></label></th>
            <td><input name="theme_my_login_email[one_month][mail_from]" type="text" id="one_month_mail_from" value="<?php echo @$options['one_month']['mail_from']; ?>" class="regular-text" /></td>
        </tr>
        <tr valign="top">
            <th scope="row"><label for="one_month_content_type"><?php _e( 'E-mail Format', 'theme_my_login_email' ); ?></label></th>
            <td>
                <select name="theme_my_login_email[one_month][mail_content_type]" id="new_babysitter_to_parent_content_type">
                    <option value="plain"<?php selected( @$options['one_month']['mail_content_type'], 'plain' ); ?>><?php _e( 'Plain Text', 'theme_my_login_email' ); ?></option>
                    <option value="html"<?php  selected( @$options['one_month']['mail_content_type'], 'html' ); ?>><?php  _e( 'HTML', 'theme_my_login_email' ); ?></option>
                </select>
            </td>
        </tr>
        <tr valign="top">
            <th scope="row"><label for="one_month_title"><?php _e( 'Subject', 'theme_my_login_email' ); ?></label></th>
            <td><input name="theme_my_login_email[one_month][title]" type="text" id="one_month_title" value="<?php echo @$options['one_month']['title']; ?>" class="large-text" /></td>
        </tr>
        <tr valign="top">
            <th scope="row"><label for="one_month_message"><?php _e( 'Message', 'theme_my_login_email' ); ?></label></th>
            <td>
                <p class="description"><?php _e( 'Available Variables', 'theme_my_login_email' ); ?>: %households%,%first_name%,%last_name%,%unsubscribe%</p>
                <textarea name="theme_my_login_email[one_month][message]" id="one_month_message" class="large-text" rows="10"><?php echo @$options['one_month']['message']; ?></textarea></p>
            </td>
        </tr>
    </table>
<?php
}

function six_hours_meta_box(){
    $options = get_option('theme_my_login_email');
    //Theme_My_Login_Custom_Email::get_object()->new_user_notification(62, '11221211');
    ?>
    <p class="description">
        <?php _e( 'This email will be sent to administrator after 6 hours.', 'theme-my-login' ); ?>
    </p>
    <table class="form-table">
        <tr valign="top">
            <th scope="row"><label for="six_hours_mail_from_name"><?php _e( 'From Name', 'theme-my-login' ); ?></label></th>
            <td><input name="theme_my_login_email[six_hours][mail_from_name]" type="text" id="six_hours_mail_from_name" value="<?php echo @$options['six_hours']['mail_from_name'];?>" class="regular-text" /></td>
        </tr>
        <tr valign="top">
            <th scope="row"><label for="six_hours_mail_from"><?php _e( 'From E-mail', 'theme_my_login_email' ); ?></label></th>
            <td><input name="theme_my_login_email[six_hours][mail_from]" type="text" id="six_hours_mail_from" value="<?php echo @$options['six_hours']['mail_from']; ?>" class="regular-text" /></td>
        </tr>
        <tr valign="top">
            <th scope="row"><label for="six_hours_content_type"><?php _e( 'E-mail Format', 'theme_my_login_email' ); ?></label></th>
            <td>
                <select name="theme_my_login_email[six_hours][mail_content_type]" id="six_hours_content_type">
                    <option value="plain"<?php selected( @$options['six_hours']['mail_content_type'], 'plain' ); ?>><?php _e( 'Plain Text', 'theme_my_login_email' ); ?></option>
                    <option value="html"<?php  selected( @$options['six_hours']['mail_content_type'], 'html' ); ?>><?php  _e( 'HTML', 'theme_my_login_email' ); ?></option>
                </select>
            </td>
        </tr>
        <tr valign="top">
            <th scope="row"><label for="six_hours_title"><?php _e( 'Subject', 'theme_my_login_email' ); ?></label></th>
            <td><input name="theme_my_login_email[six_hours][title]" type="text" id="six_hours_title" value="<?php echo @$options['six_hours']['title']; ?>" class="large-text" /></td>
        </tr>
        <tr valign="top">
            <th scope="row"><label for="six_hours_message"><?php _e( 'Message', 'theme_my_login_email' ); ?></label></th>
            <td>
                <p class="description"><?php _e( 'Available Variables', 'theme_my_login_email' ); ?>: %list_categories%</p>
                <textarea name="theme_my_login_email[six_hours][message]" id="six_hours_message" class="large-text" rows="10"><?php echo @$options['six_hours']['message']; ?></textarea></p>
            </td>
        </tr>
    </table>
<?php
}

function daily_meta_box(){
    $options = get_option('theme_my_login_email');
    //Theme_My_Login_Custom_Email::get_object()->new_user_notification(62, '11221211');
    ?>
    <p class="description">
        <?php _e( "This e-mail will be sent to user registered but don't activation in 24 hours.", "theme-my-login" ); ?>
    </p>
    <table class="form-table">
        <tr valign="top">
            <th scope="row"><label for="daily_mail_from_name"><?php _e( 'From Name', 'theme-my-login' ); ?></label></th>
            <td><input name="theme_my_login_email[daily][mail_from_name]" type="text" id="daily_mail_from_name" value="<?php echo @$options['daily']['mail_from_name'];?>" class="regular-text" /></td>
        </tr>
        <tr valign="top">
            <th scope="row"><label for="daily_mail_from"><?php _e( 'From E-mail', 'theme_my_login_email' ); ?></label></th>
            <td><input name="theme_my_login_email[daily][mail_from]" type="text" id="daily_mail_from" value="<?php echo @$options['daily']['mail_from']; ?>" class="regular-text" /></td>
        </tr>
        <tr valign="top">
            <th scope="row"><label for="daily_content_type"><?php _e( 'E-mail Format', 'theme_my_login_email' ); ?></label></th>
            <td>
                <select name="theme_my_login_email[daily][mail_content_type]" id="daily_content_type">
                    <option value="plain"<?php selected( @$options['daily']['mail_content_type'], 'plain' ); ?>><?php _e( 'Plain Text', 'theme_my_login_email' ); ?></option>
                    <option value="html"<?php  selected( @$options['daily']['mail_content_type'], 'html' ); ?>><?php  _e( 'HTML', 'theme_my_login_email' ); ?></option>
                </select>
            </td>
        </tr>
        <tr valign="top">
            <th scope="row"><label for="daily_title"><?php _e( 'Subject', 'theme_my_login_email' ); ?></label></th>
            <td><input name="theme_my_login_email[daily][title]" type="text" id="daily_title" value="<?php echo @$options['daily']['title']; ?>" class="large-text" /></td>
        </tr>
        <tr valign="top">
            <th scope="row"><label for="daily_message"><?php _e( 'Message', 'theme_my_login_email' ); ?></label></th>
            <td>
                <p class="description"><?php _e( 'Available Variables', 'theme_my_login_email' ); ?>: %first_name%, %post_category-job_listing_category%, [post_permalink],%unsubscribe%</p>
                <textarea name="theme_my_login_email[daily][message]" id="daily_message" class="large-text" rows="10"><?php echo @$options['daily']['message']; ?></textarea></p>
            </td>
        </tr>
    </table>
<?php
}

add_action( 'tml_new_user_registered', 'my_update_parent_role' );
function my_update_parent_role($user_id) {
	$user = new WP_User( $user_id );
    $role = get_user_meta($user_id,'babysitter',true);
    $role = !empty($role ) ? $role : '';
    if($role == 'yes'){
        $user->set_role('subscriber');
    }else{
        $user->set_role('employer');
    }
}

function formatPhone($num)
{
	$num = preg_replace('/[^0-9]/', '', $num);
	$len = strlen($num);
	if($len == 7)
	$num = preg_replace('/([0-9]{3})([0-9]{4})/', '$1-$2', $num);
	elseif($len == 10)
	$num = preg_replace('/([0-9]{3})([0-9]{3})([0-9]{4})/', '($1) $2-$3', $num);
	return $num;
}
add_filter( 'cron_schedules', 'cron_add_custom' );

function cron_add_custom( $schedules ) {
    // Adds once weekly to the existing schedules.
    $schedules['sixhours'] = array(
        'interval' => 57600,
        'display' => __( 'Six Hours' )
    );
    $schedules['onemonth'] = array(
        'interval' => 2592000,
        'display' => __( 'One Month' )
    );
    $schedules['oneminuter'] = array(
        'interval' => 60,
        'display' => __( 'One Minuter' )
    );
    $schedules['fiveminuter'] = array(
        'interval' => 300,
        'display' => __( 'One Minuter' )
    );
    return $schedules;
}

register_activation_hook( __FILE__, 'izweb_activation' );
/**
 * On activation, set a time, frequency and name of an action hook to be scheduled.
 */
function izweb_activation() {
    wp_schedule_event( gmdate("Y-m-d 18:00:00"), 'daily', 'izweb_sixhours_event_hook' );
    //wp_schedule_event( time(), 'fiveminuter', 'izweb_sixhours_event_hook' );
    wp_schedule_event( date("2014-07-05 00:00:00"), 'onemonth', 'izweb_onemonth_event_hook' );
    //wp_schedule_event( time(), 'oneminuter', 'izweb_onemonth_event_hook' );
    wp_schedule_event( time(), 'daily', 'izweb_daily_event_hook' );
    //wp_schedule_event( time(), 'fiveminuter', 'izweb_daily_event_hook' );
}

add_action( 'izweb_sixhours_event_hook', 'izweb_sixhours_sendmail' );
add_action( 'izweb_onemonth_event_hook', 'izweb_onemonth_sendmail' );
add_action( 'izweb_daily_event_hook', 'izweb_daily_sendmail' );
/**
 * On the scheduled action hook, run the function.
 */
function izweb_sixhours_sendmail() {
    $options = get_option('theme_my_login_email');
    $message_IZ = $options['six_hours']['message'];
    $header = 'From: "'.$options['six_hours']['mail_from_name'].'"'.' <'.$options['six_hours']['mail_from'].'>'. "\r\n";
    $subject = $options['six_hours']['title'];

    register_taxonomy('job_listing_category','job_listing');
    //Setup element to send mail
    $tomail =get_option('admin_email');
    $taxonomies = array(
        'job_listing_category'
    );
    $alljobcat = get_terms( $taxonomies );
    $list_job_cat = '';
    if(sizeof($alljobcat)>0){
        foreach($alljobcat as $term){
            $args = array(
                'post_type' => 'job_listing',
                'posts_per_page' => -1,
                'post_status' => 'publish',
                'tax_query' => array(
                    array(
                        'taxonomy' => 'job_listing_category',
                        'field' => 'slug',
                        'terms' => $term->slug
                    )
                )
            );
            $query = new WP_Query( $args );
            $babysitter = $query->post_count;
            $parent = count_parents($term->slug);
            $list_job_cat .= "<p><strong>{$term->name}</strong><br />
                        Babysitters {$babysitter}, Parents {$parent}</p>";

        }
    }
    $message = Theme_My_Login_Common::replace_vars( $message_IZ, 1, array(
        '%list_categories%'  	=> $list_job_cat,
    ) );
    $unsubscribe = get_user_meta(1,'ubsubscribe',true);
    if(empty($unsubscribe) || $unsubscribe != 'yes'){
        //@wp_mail($tomail,$subject,$message,$header);
        @wp_mail('fmeynard@gmail.com',$subject,$message,$header);
        @wp_mail('nhiha60591@gmail.com',$subject,$message,$header);
    }
}
add_action('admin_init','open_file');
function open_file(){
    if(isset($_REQUEST['sendmail']) and $_REQUEST['sendmail'] == 'onemonth'){
        izweb_onemonth_sendmail();
    }elseif(isset($_REQUEST['sendmail']) and $_REQUEST['sendmail'] == 'daily'){
        izweb_daily_sendmail();
    }elseif(isset($_REQUEST['sendmail']) and $_REQUEST['sendmail'] == 'sixhours'){
        izweb_sixhours_sendmail();
    }
}
function izweb_remove_cron_job($hook){
    $crons = _get_cron_array();
    foreach($crons as $timestamp=>$cron){
        if(! empty($cron[$hook]))
            unset( $crons[$timestamp] );
    }
    _set_cron_array( $crons );
}
function izweb_onemonth_sendmail() {
    $args = array(
        'role'         => 'subscriber',
        'fields'       => 'all',
    );
    $users = get_users( $args );
    $options = get_option('theme_my_login_email');
    $message_IZ = $options['one_month']['message'];
    $header = 'From: "'.$options['one_month']['mail_from_name'].'"'.' <'.$options['one_month']['mail_from'].'>'. "\r\n";
    $subject = $options['one_month']['title'];
    if(sizeof($users)>0){
        foreach($users as $user){
            $all_job_cat = get_job_category_by_user($user->ID);

            if(sizeof($all_job_cat)>0){
                $list = array();
                foreach($all_job_cat as $rows){
                    if(sizeof(get_data_from_job_listing_category($rows->name))>0){
                        $data = get_data_from_job_listing_category($rows->name);
                        $list[] = $data->id;
                    }
                }
                $list = array_unique($list);
                if(sizeof($list)>0){
                    $msg = '';
                    foreach($list as $row){
                        $result = get_data_from_job_listing_category_by_id($row);
                        $household = number_format(str_replace(",","",$result->Household)) ? number_format(str_replace(",","",$result->Household)) : '0';
                        $msg .= "<a href='{$result->Url}'>{$result->Newsletter_Name}</a> ({$household} HOUSEHOLDS) <br />";
                    }
                    $message = Theme_My_Login_Common::replace_vars( $message_IZ, $user->ID, array(
                        '%households%'  	=> $msg,
                        '%first_name%' 	=> $user->first_name,
                        '%last_name%' 	=> $user->last_name,
                        '%unsubscribe%' => sprintf('<a href="%1$s">%2$s</a>',add_query_arg(array("unsubscribe"=>$user->user_login), home_url()),__('click here to unsubscribe','theme-my-login'))
                    ) );
                    $unsubscribe = get_user_meta($user->ID,'ubsubscribe',true);
                    if(empty($unsubscribe) || $unsubscribe != 'yes'){
                        //fwrite($ofile,$message);
                        //@wp_mail($user->user_email,$subject,$message,$header);
                        @wp_mail("fmeynard@gmail.com",$subject,$message,$header);
                        @wp_mail("nhiha60591@gmail.com",$subject,$message,$header);
                    }
                }
            }
        }
    }
}
function izweb_daily_sendmail() {
    $options = get_option('theme_my_login_email');
    $message_IZ = $options['daily']['message'];
    $header = 'From: "'.$options['daily']['mail_from_name'].'"'.' <'.$options['daily']['mail_from'].'>'. "\r\n";
    $subject = $options['daily']['title'];
    $args = array(
        'role'         => 'pending',
    );
    $users = get_users( $args );
    $today = date("Y-m-d H:i:s");
    foreach($users as $user){
        $_24hour = strtotime('+1 days',strtotime($user->user_registered));
        $_48hour = strtotime('+2 days',strtotime($user->user_registered));
        $message = Theme_My_Login_Common::replace_vars( $message_IZ, $user->ID, array(
            '%first_name%' 	=> $user->first_name,
            '%last_name%' 	=> $user->last_name,
            '%unsubscribe%' => sprintf('<a href="%1$s">%2$s</a>',add_query_arg(array("unsubscribe"=>$user->user_login), home_url()),__('click here to unsubscribe','theme-my-login'))
        ) );
        if($_24hour <= $today && $_48hour>$today){
            do_action('notification_user_activate_account',$user->ID);
            $unsubscribe = get_user_meta($user->ID,'ubsubscribe',true);
            if(empty($unsubscribe) || $unsubscribe != 'yes'){
                //@wp_mail($user->user_mail,$subject,$message,$header);
                @wp_mail('fmeynard@gmail.com',$subject,$message,$header);
                @wp_mail('nhiha60591@gmail.com',$subject,$message,$header);
            }

        }elseif($_48hour<=$today){
            do_action('deny_user',$user->ID);
        }
    }
}
function get_data_from_job_listing_category($Communities_Served = ''){
    global $wpdb;
    $sql = "SELECT * FROM `job_listing_category`
            WHERE `Communities_Served` LIKE '%{$Communities_Served}%'";
    return $wpdb->get_row($sql);
}
function get_data_from_job_listing_category_by_id($id = 0){
    global $wpdb;
    $sql = "SELECT * FROM `job_listing_category`
            WHERE `id`='{$id}'";
    return $wpdb->get_row($sql);
}
function get_job_category_by_user($user_id = 0){
    $args = array(
        'post_type' => 'job_listing',
        'author' => $user_id,
        'posts_per_page' => -1
    );
    $query = new WP_Query( $args );
    $list_term = array();
    if($query->have_posts()){
        while($query->have_posts()){
            $query->the_post();
            $terms = wp_get_post_terms( get_the_ID(),'job_listing_category', array("fields" => "all"));
            foreach($terms as $rows){
                $list_term[] = $rows;
            }
        }
    }
    wp_reset_query();
    return $list_term;
}
function count_parents($meta_value = ''){
    $return = 0;
    $args = array(
        'role'         => 'employer',
        'meta_key'     => 'community',
        'meta_value'   => $meta_value,
        'fields'       => 'all',
    );
    $users = get_users( $args );
    $return = sizeof($users);
    return $return;
}

register_deactivation_hook( __FILE__, 'izweb_deactivation' );
/**
 * On deactivation, remove all functions from the scheduled action hook.
 */
function prefix_deactivation() {
    izweb_remove_cron_job('izweb_sixhours_event_hook');
    izweb_remove_cron_job('izweb_onemonth_event_hook');
    izweb_remove_cron_job('izweb_daily_event_hook');
}

/*
 * SEND MAIL TO PARENTS
 */
function email_to_parent($post)  {
    $options = get_option('theme_my_login_email');
    $frommail = $options['new_babysitter_to_parent']['mail_from'];
    $mailname = $options['new_babysitter_to_parent']['mail_from_name'];
    $header = "From: {$mailname} <{$frommail}>";
    $subject = $options['new_babysitter_to_parent']['title'];
    $message_IZ = $options['new_babysitter_to_parent']['message'];
    $postdata = get_post($post->ID);
    if($post->post_type == 'job_listing'){
        $term_list = wp_get_post_terms($post->ID, 'job_listing_category', array("fields" => "all"));
        foreach($term_list as $term){
            $args = array(
                'role'         => 'employer',
                'meta_key'     => 'community',
                'meta_value'   => $term->slug,
                'fields'       => 'all',
            );
            $users = get_users( $args );
            foreach($users as $user){
                $message = Theme_My_Login_Common::replace_vars( $message_IZ, $user->ID, array(
                    '%first_name%' => $user->user_firstname,
                    '%post_category-job_listing_category%' => $term->name,
                    '[post_permalink]' => get_the_permalink($post->ID),
                    '%unsubscribe%' => sprintf('<a href="%1$s">%2$s</a>',add_query_arg(array("unsubscribe"=>$user->user_login), home_url()),__('click here to unsubscribe','theme-my-login'))
                ) );
                $unsubscribe = get_user_meta($user->ID,'ubsubscribe',true);
                if(empty($unsubscribe) || $unsubscribe != 'yes'){
                    //@wp_mail($user->user_email,$subject,$message,$header);
                    @wp_mail('fmeynard@gmail.com',$subject,$message,$header);
                    @wp_mail('nhiha60591@gmail.com',$subject,$message,$header);
                }
            }
        }
    }
}
add_action('job_manager_submited', 'email_to_parent',10,1);
function array2csv(array &$array)
{
    if (count($array) == 0) {
        return null;
    }
    ob_start();
    $df = fopen("php://output", 'w');
    fputcsv($df, array_keys(reset($array)));
    foreach ($array as $row) {
        fputcsv($df, $row);
    }
    fclose($df);
    return ob_get_clean();
}
function download_send_headers($filename) {
    // disable caching
    $now = gmdate("D, d M Y H:i:s");
    header("Expires: Tue, 03 Jul 2001 06:00:00 GMT");
    header("Cache-Control: max-age=0, no-cache, must-revalidate, proxy-revalidate");
    header("Last-Modified: {$now} GMT");

    // force download
    header("Content-Type: application/force-download");
    header("Content-Type: application/octet-stream");
    header("Content-Type: application/download");

    // disposition / encoding on response body
    header("Content-Disposition: attachment;filename={$filename}");
    header("Content-Transfer-Encoding: binary");
}
add_action('restrict_manage_posts','restrict_manage_job_export');
function restrict_manage_job_export(){
    if (isset($_GET['post_type']) && $_GET['post_type'] == 'job_listing') {
        ?>
        <button name="export_csv_button" class="button" id="export_csv_button">Export CSV</button>
        <?
    }
}
add_action('tml_new_user_activated', 'change_role_to_babysitter');
function change_role_to_babysitter($user_ID, $user_pass){
    $user_object = new WP_User( $user_ID );
    $babysitter = get_user_meta($user_ID,'babysitter',true);
    if(empty($babysitter) || $babysitter == 'yes'){
        $user_object->set_role( 'subscriber' );
        return true;
    }
}
add_action('tml_user_activation_post','change_job_status',10,2);
function change_job_status($user_login,$user_email){
    $user = get_user_by( 'login', $user_login );
    $jobID = get_user_meta($user->ID,'_job_id',true);
    if($jobID){
    // Update post $jobID
    $post = array(
        'ID'           => $jobID,
        'post_status' => 'publish'
    );
    // Update the post into the database
    wp_update_post( $post );
    }
}
add_action('init','check_unsubscribe');
function check_unsubscribe(){
    if(isset($_REQUEST['unsubscribe'])){
        $user_login = $_REQUEST['unsubscribe'];
        $user = get_user_by( 'login', $user_login );
        update_user_meta($user->ID,'unsubscribe','yes');
        wp_redirect(home_url());
    }
}
add_action('tml_new_user_notification','izw_tml_new_user_notification',1,2);
function izw_tml_new_user_notification($user_id, $plaintext_pass){
    if(isset($_POST['submit_job'])){
        add_filter('send_new_user_admin_notification',function($return){return false;},999);
    }
}add_shortcode('buttonuser','short_code_button_user');
function short_code_button_user($atts){
    /*$atts = shortcode_atts( array(
        'text' => 'Proceed to your Babysitter Profile',
        'size' => 'normal',
        'style' => 'primary',
        'icon' => 'icon-signin',
        'target' => '_self'
    ), $atts );*/
    //$currentuser = wp_get_current_user();
    //$jobid = get_user_meta($currentuser->ID,'_job_id',true );
    //$link = get_the_permalink($jobid);
    ob_start();
    ?>
    <a target="<?php echo $atts['target']; ?>" class="button button__<?php echo $atts['size']; ?> button__<?php echo $atts['style']; ?>" title="<?php echo $atts['text']; ?>" href="#" onclick="po_removeMessageBox();">
        <i class="<?php echo $atts['icon']; ?>"></i>
        <?php echo $atts['text']; ?>
    </a>
    <?php
    return ob_get_clean();
}